<div class="container-fluid" style="overflow-x: auto;">
    <div class="row-fluid">
        <table class="table table-condensed">
            <tr>
                <td valign="top" align="right" style="min-width:240px">
                    <table class="table table-condensed tbl">
                        <thead>
                            <tr>
                                <td class="title" colspan="3">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>PROPIEDAD</td>
                                <td class="col">DOR</td>
                                <td class="col">CAP</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $lq = mysqli_query($CNN, "SELECT * from cms_property");
                            while ($lr = mysqli_fetch_array($lq)) {
                                ?>
                                <tr>
                                    <td><?php echo $lr["title"]; ?></td>
                                    <td width="1"><span class="label label-danger"><?php echo $lr["room"]; ?></span></td>
                                    <td width="1"><span class="label label-danger"><?php echo $lr["capacity"]; ?></span></td>                
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </td>
                <td valign="top" align="right">
                    <table class="table table-condensed tbl">
                        <thead>
                            <tr>
                                <?php
                                $moi = date("m");
                                $year = date("Y");
                                $moix = 12;
                                for ($x = $moi; $x < $moi + $moix; $x++) {
                                    $sdate = explode("-", date("Y-m-d", mktime(0, 0, 0, $x, 1, $year)));
                                    $t = date("t", mktime(0, 0, 0, $x, 1, $year));
                                    $m = date("M", mktime(0, 0, 0, $x, 1, $year));
                                    ?>
                                    <td class="title" colspan="<?php echo $t; ?>"><?php echo $m; ?></td>
                                    <?php
                                }
                                ?>
                            </tr>
                            <tr>
                                <?php
                                for ($x = $moi; $x < $moi + $moix; $x++) {
                                    $sdate = explode("-", date("Y-m-d", mktime(0, 0, 0, $x, 1, $year)));
                                    $t = date("t", mktime(0, 0, 0, $x, 1, $year));
                                    for ($i = 1; $i < $t + 1; $i++) {
                                        if ($i == 1) {
                                            ?>
                                            <td class="col moi"><?php echo $i; ?></td>
                                            <?php
                                        } elseif ($i == $t) {
                                            ?>
                                            <td class="col moe"><?php echo $i; ?></td>
                                            <?php
                                        } else {
                                            ?>
                                            <td class="col"><?php echo $i; ?></td>
                                            <?php
                                        }
                                    }
                                }
                                ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $lq = mysqli_query($CNN, "SELECT * from cms_property");
                            while ($lr = mysqli_fetch_array($lq)) {
                                ?>
                                <tr data-pid="<?php echo $lr["id"]; ?>">
                                    <?php
                                    for ($x = $moi; $x < $moi + $moix; $x++) {
                                        $sdate = explode("-", date("Y-m-d", mktime(0, 0, 0, $x, 1, $year)));
                                        $t = date("t", mktime(0, 0, 0, $x, 1, $year));
                                        for ($i = 1; $i < $t + 1; $i++) {
                                            ?>
                                            <td class="col">
                                                <?php
                                                
                                                echo '<div class="res checkin">&nbsp;</div>';
                                                echo '<div class="res checkout">&nbsp;</div>';
                                                
                                                ?>

                                            </td>
                                                <?php
                                            }
                                        }
                                        ?>
                                </tr>
                                    <?php
                                }
                                ?>
                        </tbody>
                    </table>
                </td>
            </tr>
        </table>
    </div>
</div>