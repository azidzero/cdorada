<?php
include("../../../inc/app.conf.php");
$lid = $_REQUEST["lid"];
$q = mysqli_query($CNN, "SELECT * from cms_property WHERE location='$lid'") or die(mysqli_error($CNN));
$n = mysqli_num_rows($q);
echo "<b>Se encontraron " . $n . " propiedades</b>";
?>
<div class="gantt-fixed">
    <table class="gantt-titles" width="100%">
        <thead>
            <tr>
                <td>PROPIEDAD</td>
            </tr>
            <tr>
                <td>TITULO</td>
            </tr>
        </thead>
        <?php
        while ($r = mysqli_fetch_array($q)) {
            ?>
            <tr>
                <td><?php echo $r["title"]; ?>"</td>
            </tr>
            <?php
        }
        ?>
    </table>
</div>
<div class="gantt-reserva" style="position: relative;">
    <table class="gantt-table">
        <thead>
            <tr>
                <?php
                $mes = array(
                    '01' => 'Enero',
                    '02' => 'Febrero',
                    '03' => 'Marzo',
                    '04' => 'Abril',
                    '05' => 'Mayo',
                    '06' => 'Junio',
                    '07' => 'Julio',
                    '08' => 'Agosto',
                    '09' => 'Septiembre',
                    '10' => 'Octubre',
                    '11' => 'Noviembre',
                    '12' => 'Diciembre',
                );
                $ndate = new DateTime(date('Y-m-d', mktime(0, 0, 0, date('m'), 1, date('Y'))));
                $udate = new DateTime(date('Y-m-d', mktime(0, 0, 0, date('m'), 1, date('Y') + 1)));
                $i = 0;
                while ($udate > $ndate) {
                    $sb = intval($ndate->format('m')) % 2;
                    $css = "mes" . $sb;
                    $t = $ndate->format('t');
                    echo "<td class=\"$css mes\" colspan=\"$t\">{$mes[$ndate->format('m')]}</td>";
                    $ndate->add(new DateInterval('P1M'));
                }
                ?>
            </tr>
            <tr>
                <?php
                $ndate = new DateTime(date('Y-m-d', mktime(0, 0, 0, date('m'), 1, date('Y'))));
                $udate = new DateTime(date('Y-m-d', mktime(0, 0, 0, date('m'), 1, date('Y') + 1)));
                $omes = $ndate->format('m');
                $dias = array('D', 'L', 'M', 'I', 'J', 'V', 'S');
                while ($udate > $ndate) {
                    // for ($i = 1; $i < 365; $i++) {
                    $sb = intval($ndate->format('m')) % 2;
                    $css = "mes" . $sb;
                    if ($ndate->format("w") == 6 || $ndate->format("w") == 0) {
                        $css .= " wend";
                    }
                    ?>
                    <td class="<?php echo $css; ?>">
                        <?php echo $ndate->format("d"); ?>
                    </td>
                    <?php
                    $ndate->add(new DateInterval('P1D'));
                }
                ?>
            </tr>
        </thead>
        <tbody>
            <?php
            $q = mysqli_query($CNN, "SELECT * from cms_property WHERE location='$lid'") or die(mysqli_error($CNN));
            $n = mysqli_num_rows($q);
            $y = 1;
            while ($r = mysqli_fetch_array($q)) {
                ?>
                <tr>
                    <?php
                    $ndate = new DateTime(date('Y-m-d', mktime(0, 0, 0, date('m'), 1, date('Y'))));
                    $udate = new DateTime(date('Y-m-d', mktime(0, 0, 0, date('m'), 1, date('Y') + 1)));
                    while ($udate > $ndate) {
                        $css = "";
                        if ($ndate->format("w") == 6 || $ndate->format("w") == 0) {
                            $css = "label-danger";
                        }
                        ?>
                        <td class="<?php echo $css; ?>" 
                            data-date="<?php echo $ndate->format('Y-m-d'); ?>" 
                            data-pid="<?php echo $r["id"]; ?>" 
                            width="24">
                            <!-- <?php echo $ndate->format('d'); ?> -->&nbsp;
                        </td>
                        <?php
                        $ndate->add(new DateInterval('P1D'));
                    }
                    $sq = mysqli_query($CNN, "SELECT * from crs_reserva_property WHERE pid='{$r["id"]}'");
                    $on = mysqli_num_rows($sq);
                    $x = 24;
                    if ($on > 0) {
                        while ($sr = mysqli_fetch_array($sq)) {
                            $start = new DateTime(date('Y-m-d', mktime(0, 0, 0, date('m'), 1, date('Y'))));
                            $ini = new DateTime($sr["ini"]);
                            $end = new DateTime($sr["end"]);
                            $diff = $start->diff($ini);
                            $dif = $ini->diff($end);
                            $w = intval($dif->format('%a')) * 24;
                            $x = intval($diff->format('%a')) * 24;
                            echo "<div class=\"reserva\" style=\"width:" . $w . "px;bottom: " . $y . "px;left:" . $x . "px;\">{$diff->format('')}</div>";
                        }
                    }
                    ?>
                </tr>
                <?php
                $y+=25;
            }
            ?>
        </tbody>
    </table>
</div>
<div id="modal-reserva" class="modal fade" tabindex="-1" role="dialog" style="z-index: 99998;">
    <div class="modal-dialog" style="width: 90%;z-index: 999999">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Reserva</h4>
            </div>
            <div class="modal-body" id="reservamo"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary">Guardar</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
    $('.gantt-table tr td').dblclick(function () {
        var a = $(this).attr('data-date');
    });
    function makeReserva(pid, dateStart, dateEnd) {
        $.ajax({
            method: "POST",
            url: "include/modules/planner/reserva.inc.php",
            data: {'pid': pid, 'date_ini': dateStart, 'date_end': dateEnd}
        }).done(function (msg) {
            $('#reservamo').html(msg);
        });
        $('#modal-reserva').modal('show');
    }
    function makeDiv(x, w, pid) {
        var y = pid;
        var html = "<div class=\"reserva\" style=\"width:" + w + "px;bottom: " + y + "px;left:" + x + "px;\">" + pid + "</div>";
    }
    /*
     * Dinamic Table selection
     */
    $(function () {
        var colStart, colEnd;
        var isMouseDown = false, isHighlighted;
        var currentCol;
        $(".gantt-table td").mousedown(function () {
            colStart = this.getAttribute('data-date');
            colEnd = this.getAttribute('data-date');
            $(".gantt-table td").removeClass('selected');
            isMouseDown = true;
            currentCol = this.getAttribute("data-pid");
            $(this).toggleClass("selected");
            isHighlighted = $(this).hasClass("selected");
            return false; // prevent text selection
        });
        $(".gantt-table td").mouseover(function () {
            if (isMouseDown) {
                if (currentCol === this.getAttribute("data-pid")) {
                    colEnd = this.getAttribute('data-date');
                    $(this).toggleClass("selected", isHighlighted);
                }
            }
        });
        $(".gantt-table td").bind("selectstart", function () {
            return false;
        });

        $(".gantt-table td").mouseup(function () {
            isMouseDown = false;
            makeReserva(currentCol, colStart, colEnd);
        });
    });
    $(document).ready(function () {
        $('#gantt-fixed').scroll(function (e) {
            var a = $(this).offset();
            console.log(a.top);

        });

    });
</script>