<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$mod = new MODULE;
$mod->url = "planner";
$mod->name = "Planificador";
$mod->icon = "planner";
$mod->desc="Planificador";

$mod->addSection('Planificador', 'planner');
//$mod->addOption('rates', 'Agregar', 0);
//$mod->addOption('rates', 'Administrar', 2);