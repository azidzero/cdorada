<?php
include("../../../inc/app.conf.php");
$op = filter_input(INPUT_POST, "op");
$activ_autosave = 0;
$lq = mysqli_query($CNN, "SELECT * from cms_translation_lang WHERE status=1");
$language = array();
while ($lr = mysqli_fetch_array($lq)) {
    $language[] = $lr['iso_639_1'];
}
switch ($op) {
//AGREGA EL CONTENIO A LA MODAL
    case 0:
        $tab = filter_input(INPUT_POST, "table");
        ?>
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Nuevo General</h4>
        </div>
        <div class="modal-body">
            <form id='formadd' name='formadd' class="form" method='POST'>
                <input type="text" name="catalog" id="catalog" value="<?php echo $tab; ?>" class="hidden"/>
                <input type="text" name="op" id="op" value="0" class="hidden"/>
                <input type="text" name="idsav" id="idsav" value="0" class="hidden"/>
                <div class="row " style="padding: 1%;">
                    <div class="col-lg-12">
                        <div>
                            <ul class="nav nav-tabs" role="tablist">
                                <?php
                                foreach ($language as $L) {
                                    ?>
                                    <li role="presentation" class="<?php
                                    if ($L == "es") {
                                        echo "active";
                                    }
                                    ?>">
                                        <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab" class="text-capitalize">
                                            <?php echo $L; ?>
                                            <?php if ($L == "es") { ?>
                                                <span class="label label-danger">Requerido</span>
                                                <?php
                                            }
                                            ?>
                                        </a>
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                            <div class="tab-content" style="padding-bottom:.5%;padding-top: 1%;">
                                <?php
                                foreach ($language as $L) {
                                    ?>
                                    <div role="tabpanel"style="padding:0%;" class="tab-pane  <?php
                                    if ($L == "es") {
                                        echo "active";
                                    }
                                    ?> " id="tab_<?php echo $L; ?>">
                                        <div class="row ">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">Nombre<small><?php echo "(" . $L . ")"; ?></small>:</div>
                                                        <input type="text" name="name_<?php echo $L; ?>" id="name_<?php echo $L; ?>" class="form-control " placeholder="NOMBRE"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">Tipo:</div>
                                <select id="tdato" name="tdato" class="form-control" <?php if ($activ_autosave == 1) { ?>onblur="autosave(this.name, 'tipo');"<?php } ?> >
                                    <option value="0">SI/NO</option >
                                    <option value="1">Numerico</option >
                                    <option value="2">Texto</option >
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">Activo:</div>
                                <select id="activ" name="activ"  class="form-control" <?php if ($activ_autosave == 1) { ?> onblur="autosave(this.name, 'active');" <?php } ?>>
                                    <option value="0">NO</option >
                                    <option value="1">SI</option >
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">Requerido:</label></div>
                                <select id="raq" name="raq"  class="form-control" <?php if ($activ_autosave == 1) { ?> onblur="autosave(this.name, 'required');" <?php } ?>>
                                    <option value="0">NO</option >
                                    <option value="1">SI</option >
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">Medida:</label></div>
                                <input type="text" name="unit" id='unit' class="form-control" placeholder="vacio si no aplica" <?php if ($activ_autosave == 1) { ?> onblur="autosave(this.name, 'unidad');"<?php } ?>/>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">Valor Predeterminado:</label></div>
                                <input type="text" name="valp" id='valp' class="form-control" <?php if ($activ_autosave == 1) { ?> onblur="autosave(this.name, 'valor');"<?php } ?>/>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-primary" onclick="altaitem();">Guardar</button>
        </div>
        <?php
        break;
    case 1://Editar el item y guardar los cambios
        $id = filter_input(INPUT_POST, "itemid");
        $nams = "select lang,caption,tname from cms_addon_translate where aid=$id";
        $gtnlan = mysqli_query($CNN, $nams);
        $arr = array();
        $tab = null;
        $falt = 0;
        $lg = array(); //lenguaje de array
        while ($g = mysqli_fetch_array($gtnlan)) {
            //$tab = null;
            $arr[$g['lang']] = $g['caption'];
            $tab = $g['tname'];
            $lg[$falt] = $g['lang'];
            $falt++;
        }
        $result = array_diff($language, $lg);
        $new = "insert into cms_addon_translate  (tname,aid,lang,caption) values";
        foreach ($result as $u) {
            $new.="('$tab','$id','$u',''),";
        }
        $new = substr($new, 0, -1);
        $gtnw = mysqli_query($CNN, $new)or $err = "error al ingresar nuevo lenguaje" . mysqli_error($CNN);
        if (!isset($err)) {
            unset($arr);
            $arr = array();
            $nmb = "select lang,caption,tname from cms_addon_translate where aid=$id";
            $gtl = mysqli_query($CNN, $nams);
            while ($g = mysqli_fetch_array($gtl)) {
                $tab = null;
                $arr[$g['lang']] = $g['caption'];
                $tab = $g['tname'];
            }
        }
        ?>
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Nuevo General</h4>
        </div>
        <div class="modal-body">
            <form id='formedit' name='formedit' class="form" method='POST'>
                <input type="text" name="catalog" id="catalog" value="<?php echo $tab; ?>" class="hidden"/>
                <input type="text" name="op" id="op" value="2" class="hidden"/>
                <input type="text" name="idsav" id="idsav" value="<?php echo $id; ?>" class="hidden"/>
                <div class="row " style="padding: 1%;">
                    <div class="col-lg-12">
                        <div>
                            <ul class="nav nav-tabs" role="tablist">
                                <?php
                                foreach ($language as $L) {
                                    ?>
                                    <li role="presentation" class="<?php
                                    if ($L == "es") {
                                        echo "active";
                                    }
                                    ?>">
                                        <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab" class="text-capitalize">
                                            <?php echo $L; ?>
                                            <?php if ($L == "es") { ?>
                                                <span class="label label-danger">Requerido</span>
                                                <?php
                                            }
                                            ?>
                                        </a>
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                            <div class="tab-content" style="padding-bottom:.5%;padding-top: 1%;">
                                <?php
                                foreach ($language as $L) {
                                    ?>
                                    <div role="tabpanel"style="padding:0%;" class="tab-pane  <?php
                                    if ($L == "es") {
                                        echo "active";
                                    }
                                    ?> " id="tab_<?php echo $L; ?>">
                                        <div class="row ">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">Nombre<small><?php echo "(" . $L . ")"; ?></small>:</div>
                                                        <input type="text" name="name_<?php echo $L; ?>" id="name_<?php echo $L; ?>" value="<?php echo $arr[$L] ?>" class="form-control " placeholder="NOMBRE"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                $SQL = mysqli_query($CNN, "select * from cms_addons where id=$id");
                while ($ro = mysqli_fetch_array($SQL)) {
                    ?>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">Tipo:</div>
                                    <select id="tdato" name="tdato" class="form-control" <?php if ($activ_autosave == 1) { ?>onblur="autosave(this.name, 'tipo');"<?php } ?> >
                                        <option value="0" <?php
                                        if ($ro['tipo'] == 0) {
                                            echo "selected";
                                        }
                                        ?>>SI/NO</option >
                                        <option value="1"<?php
                                        if ($ro['tipo'] == 1) {
                                            echo "selected";
                                        }
                                        ?>>Numerico</option >
                                        <option value="2"<?php
                                        if ($ro['tipo'] == 2) {
                                            echo "selected";
                                        }
                                        ?>>Texto</option >
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">Activo:</div>
                                    <select id="activ" name="activ"  class="form-control" <?php if ($activ_autosave == 1) { ?> onblur="autosave(this.name, 'active');" <?php } ?>>
                                        <option value="0"<?php
                                        if ($ro['active'] == 0) {
                                            echo "selected";
                                        }
                                        ?>>NO</option >
                                        <option value="1"<?php
                                        if ($ro['active'] == 1) {
                                            echo "selected";
                                        }
                                        ?>>SI</option >
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">Requerido:</label></div>
                                    <select id="raq" name="raq"  class="form-control" <?php if ($activ_autosave == 1) { ?> onblur="autosave(this.name, 'required');" <?php } ?>>
                                        <option value="0"<?php
                                        if ($ro['required'] == 0) {
                                            echo "selected";
                                        }
                                        ?>>NO</option >
                                        <option value="1"<?php
                                        if ($ro['required'] == 1) {
                                            echo "selected";
                                        }
                                        ?>>SI</option >
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">Medida:</label></div>
                                    <input type="text" name="unit" id='unit' value="<?php echo $ro['unidad']; ?>" class="form-control" placeholder="vacio si no aplica" <?php if ($activ_autosave == 1) { ?> onblur="autosave(this.name, 'unidad');"<?php } ?>/>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">Valor Predeterminado:</label></div>
                                    <input type="text" name="valp" id='valp'value="<?php echo $ro['valor']; ?>" class="form-control" <?php if ($activ_autosave == 1) { ?> onblur="autosave(this.name, 'valor');"<?php } ?>/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-primary" onclick="manda_alta();">Guardar</button>
        </div>
        <?php
        break;
    case 2:
        $datatype = filter_input(INPUT_POST, "tdato");
        $cat = filter_input(INPUT_POST, "catalog");
        $isactive = filter_input(INPUT_POST, "activ");
        $reque = filter_input(INPUT_POST, "raq");
        $unid = filter_input(INPUT_POST, "unit");
        $va = filter_input(INPUT_POST, "valp");
        $id = filter_input(INPUT_POST, "idsav");
        $actual = mysqli_query($CNN, "UPDATE cms_addons SET tipo = '$datatype',valor = '$va',active = '$isactive',required = '$reque',unidad = '$unid' WHERE id =$id")or $err = "error al actualizar" . mysqli_error($CNN);
        if (!isset($err)) {
            $updtrans = "";
            foreach ($language as $LANG) {
                $updtrans .= "update cms_addon_translate set caption='" . filter_input(INPUT_POST, 'name_' . $LANG) . "' where  lang='$LANG' and aid=$id and tname='$cat';";
            }
            if (mysqli_multi_query($CNN, $updtrans)) {
                do {
                    /* almacenar primer juego de resultados */
                    if ($resu = mysqli_store_result($CNN)) {
                        while ($row = mysqli_fetch_row($resu)) {
                            // printf("%s\n", $row[0]);
                        }
                        mysqli_free_result($resu);
                    }
                    /* mostrar divisor */
                    if (mysqli_more_results($CNN)) {
                        //printf("-----------------\n");
                    }
                } while (mysqli_next_result($CNN) && mysqli_more_results($CNN));
            }
            echo "1";
        } else {
            echo $err;
        }
        break;
    case 3:
        $id = filter_input(INPUT_POST, "id");
        $item = "";
        $mno = mysqli_query($CNN, "select * from cms_addon_translate where aid=$id and lang='es'");
        while ($i = mysqli_fetch_array($mno)) {
            $item = $i['caption'];
        }
        ?>
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Eliminar</h4>
        </div>
        <div class="modal-body">
            <div class="lert alert-danger text-justify text-uppercase">
                <h4>Al eliminar este elemento del catalogo, afectara sus alojamientos</h4><br>
                <h3>Este cambio <b>NO sera reversible</b></h3>
                <b> ¿Desea continuar?</b>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-success" onclick="eliminaitem(<?php echo $id; ?>)">Aceptar</button>
        </div>
        <?php
        break;
    case 4:
        $id = filter_input(INPUT_POST, "itm");
        $borra = mysqli_query($CNN, "delete from cms_property_catalogs where id=$id")or $err = "error al borrar el item" . mysqli_error($CNN);
        if (!isset($err)) {
            $delang = mysqli_query($CNN, "delete from cms_addon_translate where aid=$id")or $err = "Error al eliminar el item #2" . mysqli_error($CNN);
            if (!isset($err)) {
                echo "1";
            } else {
                echo $err;
            }
        }
        break;
    case 5:
        ?>
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Agregar Catalogo</h4>
        </div>
        <div class="modal-body">
            <form id='add_cat' name='add_cat' class="form" method='POST'>
                <div class="row ">
                    <div class="col-lg-12">
                        <div>
                            <ul class="nav nav-tabs" role="tablist">
                                <?php
                                foreach ($language as $L) {
                                    ?>
                                    <li role="presentation" class="<?php
                                    if ($L == "es") {
                                        echo "active";
                                    }
                                    ?>">
                                        <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab" class="text-capitalize">
                                            <?php echo $L; ?>
                                            <?php if ($L == "es") { ?>
                                                <span class="label label-danger">Requerido</span>
                                                <?php
                                            }
                                            ?>
                                        </a>
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                            <div class="tab-content" style="padding-bottom:.5%;padding-top: 1%;">
                                <?php
                                foreach ($language as $L) {
                                    ?>
                                    <div role="tabpanel"style="padding:0%;" class="tab-pane  <?php
                                    if ($L == "es") {
                                        echo "active";
                                    }
                                    ?> " id="tab_<?php echo $L; ?>">
                                        <div class="row ">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">Nombre<small><?php echo "(" . $L . ")"; ?></small>:</div>
                                                        <input type="text" name="name_<?php echo $L; ?>" id="name_<?php echo $L; ?>" class="form-control input-lg " placeholder="NOMBRE"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="text" id="op" name="op" value="6" class="hidden">
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-primary" onclick="savecat();">Guardar</button>
        </div>
        <?php
        break;
    case 6:
        $nes = filter_input(INPUT_POST, "name_es");
        $getname = mysqli_query($CNN, "select * from cms_catalog where common='$nes'");
        $nor = mysqli_num_rows($getname);
        if ($nor <= 0) {
            $ines = mysqli_query($CNN, "insert into cms_catalog (common) values('$nes')")or $err = "No se pudo guardar el catalogo<br>" . mysqli_error($CNN);
            if (!isset($err)) {
                $ado = mysqli_insert_id($CNN);
                $olang = "insert into cms_catalog_translate (aid,lang,caption)values";
                foreach ($language as $l) {
                    if ($l != 'es') {
                        $olang.="('$ado','$l','" . filter_input(INPUT_POST, 'name_' . $l) . "'),";
                    }
                }
                $qrylang = substr($olang, 0, -1);
                $ex = mysqli_query($CNN, $qrylang) or $err = "error al crear el catalogo:<br>$qrylang<br>" . mysqli_error($CNN);
                if (!isset($err)) {
                    echo '1|<tr id="row_' . $ado . '">'
                    . '<td >' . $ado . '</td>'
                    . '<td>' . $nes . '</td>'
                    . '<td>0</td>'
                    . '<td>'
                    . '<div class=" btn-group ">'
                    . '<button class="btn btn-danger"alt="Eliminar" title="Eliminar"onclick="delcat(' . $ado . ')"><i class="fa fa-trash"></i></button>'
                    . '<button class="btn btn-warning"alt="Editar" title="Editar"onclick="editcat(' . $ado . ')"><i class="fa fa-edit "></i></button>'
                    . '</div>'
                    . '</td>'
                    . '</tr>';
                } else {
                    echo "0|" . $err;
                }
            } else {
                echo "0|" . $err;
            }
        } else {
            echo "2|Ya existe un catalogo con este nombre";
        }
        break;
    case 7:
        $id = filter_input(INPUT_POST, "id");
        $item = "";
        $mno = mysqli_query($CNN, "select * from cms_catalog where id=$id");
        while ($i = mysqli_fetch_array($mno)) {
            $item = $i['common'];
        }
        ?>
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title text-danger" id="exampleModalLabel">Eliminar</h4>
        </div>
        <div class="modal-body" style="padding:0px;">
            <div class="lert alert-danger text-justify text-uppercase" style="padding: 2%;">
                <h4>Al eliminar el catalogo <b><?php echo $item; ?></b>, afectara sus alojamientos</h4><br>
                <h3>Este cambio <b>NO sera reversible</b></h3>
                <b> ¿Desea continuar?</b>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-success" onclick="borracat(<?php echo $id; ?>)">Aceptar</button>
        </div>
        <?php
        break;
    case 8:
        $id = filter_input(INPUT_POST, "id");
        $del = mysqli_query($CNN, "DELETE FROM cms_catalog_translate WHERE aid=$id") or $err = "error al eliminar los idiomas del catalogo" . mysqli_error($CNN);
        if (!isset($err)) {
            $del2 = mysqli_query($CNN, "DELETE FROM cms_catalog WHERE id=$id") or $err = "error al eliminar los idiomas del catalogo" . mysqli_error($CNN);
            if (!isset($err)) {
                echo "1";
            } else {
                echo $err;
            }
        } else {
            echo $err;
        }
        break;
    case 9:
        $id = filter_input(INPUT_POST, "id");
        $item = "";
        $mno = mysqli_query($CNN, "select * from cms_catalog where id=$id");
        while ($i = mysqli_fetch_array($mno)) {
            $item = $i['common'];
        }
        $lq = mysqli_query($CNN, "SELECT * from cms_catalog_translate WHERE aid=$id");
        $txt = array();
        $cont=array();
        while ($r = mysqli_fetch_array($lq)) {
            $txt[$r['lang']] = $r['caption'];
            $cont[]=$r['lang'];
        }
        print_r($cont);
        ?>
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Editar Catalogo</h4>
        </div>
        <div class="modal-body">
            <form id='add_cat' name='add_cat' class="form" method='POST'>
                <div class="row ">
                    <div class="col-lg-12">
                        <div>
                            <ul class="nav nav-tabs" role="tablist">
                                <?php
                                foreach ($language as $L) {
                                    ?>
                                    <li role="presentation" class="<?php
                                    if ($L == "es") {
                                        echo "active";
                                    }
                                    ?>">
                                        <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab" class="text-capitalize">
                                            <?php echo $L; ?>
                                            <?php if ($L == "es") { ?>
                                                <span class="label label-danger">Requerido</span>
                                                <?php
                                            }
                                            ?>
                                        </a>
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                            <div class="tab-content" style="padding-bottom:.5%;padding-top: 1%;">
                                <?php
                                foreach ($language as $L) {
                                    ?>
                                    <div role="tabpanel"style="padding:0%;" class="tab-pane  <?php
                                    if ($L == "es") {
                                        echo "active";
                                    }
                                    ?> " id="tab_<?php echo $L; ?>">
                                        <div class="row ">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">Nombre<small><?php echo "(" . $L . ")"; ?></small>:</div>
                                                        <input type="text" name="name_<?php echo $L; ?>" id="name_<?php echo $L; ?>"value="<?php if ($L == "es") {
                                 echo $item;
                             } else {
                                 echo $txt[$L];
                             } ?>" class="form-control input-lg " placeholder="NOMBRE"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
            <?php
        }
        ?>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="text" id="op" name="op" value="10" class="hidden">
                <input type="text" id="id" name="id" value="<?php echo $id; ?>" class="hidden">
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-primary" onclick="updacat(<?php echo $id;?>);">Actualizar</button>
        </div>
        <?php
        break;
    case 10:
        $id = filter_input(INPUT_POST, "id");
        $nes = filter_input(INPUT_POST, "name_es");
        $getname = mysqli_query($CNN, "select * from cms_catalog where common='$nes'");
        $nor = mysqli_num_rows($getname);
        if ($nor <= 1) {
            $ines = mysqli_query($CNN, "update cms_catalog set common='$nes' where id=$id")or $err = "No se pudo Actualizar el catalogo<br>" . mysqli_error($CNN);
            if (!isset($err)) {
                $ado = mysqli_insert_id($CNN);
                $olang="";
                foreach ($language as $l) {
                    if ($l != 'es') {
                        $olang.="update cms_catalog_translate set caption='" . filter_input(INPUT_POST, 'name_' . $l) . "' where aid=$id and lang='$l');";
                    }
                }
                $qrylang = substr($olang, 0, -1);
                if (mysqli_multi_query($CNN, $qrylang)) {
                    do {
                        /* almacenar primer juego de resultados */
                        if ($resu = mysqli_store_result($CNN)) {
                            while ($row = mysqli_fetch_row($resu)) {
                                // printf("%s\n", $row[0]);
                            }
                            mysqli_free_result($resu);
                        }
                        /* mostrar divisor */
                        if (mysqli_more_results($CNN)) {
                            //printf("-----------------\n");
                        }
                    } while (mysqli_next_result($CNN) && mysqli_more_results($CNN));
                }
                echo '1|'
                . '<td >' . $ado . '</td>'
                . '<td>' . $nes . '</td>'
                . '<td>0</td>'
                . '<td>'
                . '<div class=" btn-group ">'
                . '<button class="btn btn-danger"alt="Eliminar" title="Eliminar"onclick="delcat(' . $id . ')"><i class="fa fa-trash"></i></button>'
                . '<button class="btn btn-warning"alt="Editar" title="Editar" onclick="editcat(' . $id . ')"><i class="fa fa-edit "></i></button>'
                . '</div>'
                . '</td>';
            } else {
                echo "0|" . $err;
            }
        } else {
            echo "2|Ya existe un catalogo con este nombre";
        }
        break;
}