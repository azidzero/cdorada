<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$mod = new MODULE;
$mod->url = "property";
$mod->name = "Alojamientos";
$mod->icon = "property";
$mod->desc = "Control de Alojamientos";
$mod->addSection('Catalogos', 'catalog');
$mod->addOption('catalog', 'General', 0);
$mod->addOption('catalog', 'Interior', 10);
$mod->addOption('catalog', 'Exterior', 20);
$mod->addOption('catalog', 'Equipamiento', 30);
//$mod->addOption('catalog', '<b>Administrar</b>', 40);

$mod->addSection('Destinos', 'locale');
$mod->addOption('locale', 'Agregar', 0);
$mod->addOption('locale', 'Administrar', 2);

$mod->addSection('Tipos', 'type');
$mod->addOption('type', 'Agregar', 0);
$mod->addOption('type', 'Administrar', 2);

$mod->addSection('Alojamiento', 'housing');
$mod->addOption('housing', 'Agregar', 0);
$mod->addOption('housing', 'Administrar', 2);


$mod->addSection('Extras', 'extra');
//$mod->addOption('offer', 'Agregar', 0);
//$mod->addOption('deal', 'Administrar', 2);
//$mod->addOption('housing', 'Imagenes', 8);

//$mod->addSection('Opciones', 'option');
