<h2>Alojamiento</h2>
<?php
$mes = array("", "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic");
$activ_autosave = 0;
$lq = mysqli_query($CNN, "SELECT * from cms_translation_lang WHERE status=1");
$language = array();
while ($lr = mysqli_fetch_array($lq)) {
    $language[] = $lr['iso_639_1'];
}
?>
<div class="modal fade bs-example-modal-sm" id="clonehou" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
    <div class="modal-dialog modal-sm">
        <div class="modal-content" id="content_clon">
        </div>
    </div>
</div>
<?php
switch ($o) {
    case 0:
        ?>
        <small> <h4>Agregar</h4></small>
        <form action="./?m=property&s=housing&o=1" method="post" class="form"name="formhousing" id="formhousing" enctype="multipart/form-data" >
            <div class="checkbox-1" >
                <br><br>
                <span>Activo/Inactivo</span>
                <input type="checkbox" id="ejemplo-1" value="1" name="ejemplo-1"  class="hidden" onclick="status();"/>
                <label for="ejemplo-1"></label>
            </div>
            <input type="number" value="0" id="rent-status" name="rent-status" class="hidden"><!---STATUS DE LA PROPIEDAD 0=INACTIVO / 1=ACTIVO---->
            <input type="text" id="idsav" name="idsav" value="0" class="hidden" ><!--ID DE PROPIDAD GUARDADA 0=GUARDADA/N=GUIARDADO--->
            <input type="text" id="shlang" name="shlang" value="0" class="hidden" ><!--DESC CORTA 0=GUARDADA/N=GUARDADO--->
            <input type="text" id="lonlang" name="lonlang" value="0" class="hidden" ><!--DESC LARGA 0=GUARDADA/N=GUARDADO--->
            <div role="tabpanel">
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#informacion" aria-controls="informacion" role="tab" data-toggle="tab">Informaci&oacute;n</a></li>
                    <?php
                    $gettabs = mysqli_query($CNN, "select * from cms_catalog");
                    while ($name = mysqli_fetch_array($gettabs)) {
                        ?>
                        <li role="presentation" class="">
                            <a href="#<?php echo $name['id']; ?>" aria-controls="<?php echo $name['id']; ?>" role="tab" data-toggle="tab" onclick="autosavetab('<?php echo $name['id']; ?>');">
                                <?php echo $name['common']; ?>
                            </a>
                        </li>
                        <?php
                    }
                    ?>
                    <li role="presentation" class=""><a href="#Precios" aria-controls="informacion" role="tab" onclick="checaguarda();" data-toggle="tab">Precios</a></li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="informacion" style="padding:5px;">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon">Nombre:</div>
                                        <input type="text"  id="rent-title" name="rent-title" class="form-control" onblur="savehousing(this.name, this.value);" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 ">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon">Referencia:</div>
                                        <input type="text" id="rent-ref" name="rent-ref" size="30" class="form-control"  onblur="savehousing(this.name, this.value);"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon">Modo:</div>
                                        <select id="rent-modo" name="rent-modo" class="form-control" onblur="savehousing(this.name, this.value);">
                                            <option value="0">Alquiler</option>
                                            <option value="1">Gestion</option>
                                            <option value="2">Venta</option>
                                            <option value="3">Traspaso</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon">Tipo:</div>
                                        <select id="rent-tipo" name="rent-tipo" class="form-control select" onblur="savehousing(this.name, this.value);" style="width:100%;" >
                                            <?php
                                            $consulta = "SELECT * from cms_property_type ";
                                            $result = mysqli_query($CNN, $consulta);
                                            while ($x = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                                                ?>
                                                <option value='<?php echo $x['id']; ?>'><?php echo $x['name']; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon">Ba&ntilde;os:</div>
                                        <input type="number" id="rent-bathroom" name="rent-bathroom" size="10" value="0" min="0"class="form-control" onblur="savehousing(this.name, this.value);" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon">Servicios:</div>
                                        <input type="number" id="rent-servicios" name="rent-servicios" size="10" value="0" min="0"class="form-control" onblur="savehousing(this.name, this.value);" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon">Habitaciones:</div>
                                        <input type="number" id="rent-room" name="rent-room" value="0"size="10" min="0"class="form-control" onblur="savehousing(this.name, this.value);"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon">Ocupantes:</div>
                                        <input type="number" id="rent-capacity" name="rent-capacity" size="10"value="0" min="0"class="form-control" onblur="savehousing(this.name, this.value);" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <div class="input-group-addon">Ubicacion:</div>
                                            <select id="rent-location" name="rent-location" class="form-control" onblur="savehousing(this.name, this.value);">
                                                <?php
                                                $consulta = "SELECT * from cms_property_locale ";
                                                $result = mysqli_query($CNN, $consulta);
                                                while ($x = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                                                    ?>
                                                    <option value='<?php echo $x['id']; ?>'><?php echo $x['name']; ?></value>
                                                    <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class=row>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-addon">Direcci&oacute;n:</div>
                                                    <input type="text" id="rent-address" name="rent-address"  size="200" class="form-control" onkeypress="mapadire(this.value);" onblur="savehousing(this.name, this.value);"/>
                                                    <input type="text" id="dirho_num" value="0" class="hidden">
                                                </div>
                                            </div>
                                        </div>
                                        <!----INICIAN LAS TRADUCCIONES--->
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div>
                                                    <ul class="nav nav-tabs" role="tablist">
                                                        <?php
                                                        foreach ($language as $L) {
                                                            ?>
                                                            <li role="presentation" class="<?php
                                                            if ($L == "es") {
                                                                echo "active";
                                                            }
                                                            ?>">
                                                                <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab" class="text-capitalize">
                                                                    <?php echo $L; ?>
                                                                    <?php if ($L == "es") { ?>
                                                                        <span class="label label-danger">Requerido</span>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </a>
                                                            </li>
                                                            <?php
                                                        }
                                                        ?>
                                                    </ul>
                                                    <div class="tab-content">
                                                        <?php
                                                        foreach ($language as $L) {
                                                            ?>
                                                            <div role="tabpanel"style="padding:0%;" class="tab-pane  <?php
                                                            if ($L == "es") {
                                                                echo "active";
                                                            }
                                                            ?> " id="tab_<?php echo $L; ?>">
                                                                <br>
                                                                <div class="row ">
                                                                    <div class="col-lg-12">
                                                                        <div class="form-group">
                                                                            <div class="input-group">
                                                                                <div class="input-group-addon">Descripci&oacute;n Corta<small><?php echo "(" . $L . ")"; ?></small></div>
                                                                                <input type="text" id="rent-short_<?php echo $L; ?>" name="rent-short_<?php echo $L; ?>"  size="200" class="form-control" onblur="saveshort(this.name, this.value);"/>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-12">
                                                                        <div class="form-group">
                                                                            <div class="input-group">
                                                                                <div class="input-group-addon">Descripci&oacute;n Larga<small><?php echo "(" . $L . ")"; ?></small></div>
                                                                                <textarea type="text" id="rent-large_<?php echo $L; ?>" name="rent-large_<?php echo $L; ?>" rows="6" cols="100%" class="form-control" onblur="savelong(this.name, this.value);" /></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6"><!---Aqui va el mapa--->
                                <div id="test" class="gmap3"></div>
                                <input type="text" name="lat" id="lat" value="0" class="hidden"><!--latitud-->
                                <input type="text" name="long" id="long" value="0"class="hidden" ><!---Longitud--->
                            </div>
                        </div>
                    </div>
                    <!-- Dinamico -->
                    <?php
                    $gettabs = mysqli_query($CNN, "select * from cms_catalog");
                    while ($p = mysqli_fetch_array($gettabs)) {
                        ?>
                        <input type="text" class="hidden" value="0" id="tabsav_<?php echo $p['id']; ?>" name="tabsav_<?php echo $p['id']; ?>">
                        <div role="tabpanel" class="tab-pane" id="<?php echo $p['id']; ?>" name="<?php echo $p['id']; ?>" >
                            <?php
                            $addons = "SELECT a.caption,b.* FROM  cms_addon_translate a INNER JOIN cms_addons b ON (a.aid=b.id) WHERE tname='{$p['id']}' AND lang='es'";
                            $ado = mysqli_query($CNN, $addons) or $err = "error al traer el catalogo <b>{$p['common']}<b><br>" . mysqli_error($CNN);
                            if (!isset($err)) {
                                ?>
                                <div class = "row row-fluid" style = "padding:1%;">
                                    <?php
                                    while ($r = mysqli_fetch_array($ado)) {
                                        $req = null;
                                        unset($idimpt);
                                        $idimpt = $p['id'] . "_" . $r['id'];
                                        if ($r['required'] == 1) {
                                            $req = 'checked="checked" data-save="1" readonly="readonly" onclick="javascript: return false;"';
                                        } else {
                                            $req = 'onclick="saveitem(' . $p['id'] . ',' . $r['id'] . ');" data-save="0"';
                                        }
                                        ?>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-addon">
                                                        <input type="checkbox"  id="<?php echo $idimpt; ?>" value="<?php echo $r['id']; ?>" <?php echo $req; ?> /><?php echo strtoupper($r['caption']); ?>
                                                    </div>
                                                    <?php
                                                    switch (($r['tipo'])) {
                                                        case 0:
                                                            ?>
                                                            <input type="radio" id="<?php echo $idimpt; ?>_data" name="<?php echo $idimpt; ?>_data" value="1" onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);" <?php
                                                            if ($r["valor"] == 1) {
                                                                echo "checked";
                                                            }
                                                            ?> />Si
                                                            <input type="radio" id="<?php echo $idimpt; ?>_data" name="<?php echo $idimpt; ?>_data"  value="0" onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);" <?php
                                                            if ($r["valor"] == 0) {
                                                                echo "checked";
                                                            }
                                                            ?>/>No
                                                                   <?php
                                                                   break;
                                                               case 1:
                                                                   ?>
                                                            <input type="number" id="<?php echo $idimpt; ?>_data" value="<?php echo $r["valor"]; ?>" class="form-control"  onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);"onchange="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);"/>
                                                            <div class="input-group-addon"></div>
                                                            <?php
                                                            break;
                                                        case 2:
                                                            ?>
                                                            <input type="text"id="<?php echo $idimpt; ?>_data"  value="<?php echo $r["valor"]; ?>" class="form-control"  placeholder="Text"  onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);"/>
                                                            <div class="input-group-addon"></div>
                                                            <?php
                                                            break;
                                                    }
                                                    ?>

                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                                <?php
                            } else {
                                ?>
                                <div class="alert alert-danger">
                                    <?php echo $err; ?>
                                </div>
                                <?php
                                unset($err);
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div role="tabpanel" class="tab-pane" id="Precios">
                        <div id="con_tyo" name="con_tyo"class="content" style="display:none;">
                            <div class="row">
                                <div class="col-lg-8">
                                    &nbsp;<big><label class="label label-default">Tarifas y Ofertas</label></big><br><br>
                                    <div class="modal fade" id="mdloffer" name="mdloffer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" >
                                            <div class="modal-content" >
                                                <div class="modal-header">
                                                    <big> <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></big>
                                                    <h4 class="modal-title" id="exampleModalLabel">Ofertas</h4>
                                                </div>
                                                <div class="modal-body" id="conbody" name="conbody">

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-warning" data-dismiss="modal">Cerrar</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade bs-example-modal-lg"id="ctarifa" name="ctarifa" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="exampleModalLabel">Tarifas</h4>
                                                </div>
                                                <div class="modal-body" id="cbody" name="cbody">

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-warning" data-dismiss="modal">Cerrar</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade bs-example-modal-sm" id="de_tarifa" name="de_tarifa"  tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
                                        <div class="modal-dialog modal-sm">
                                            <div class="modal-content" id="content_delt" style="padding:3%;">
                                            </div>
                                        </div>
                                    </div>
                                    <a href="JavaScript:void(0)" onclick="cattarif(document.getElementById('idsav').value);"><i class="fa fa-plus"></i> Tarifas</a>
                                    <table id="tabla_tarifa" name="tabla_tarifa" class="table table-responsive table-hover" width="100%">
                                        <thead>
                                        <th width="1"></th>
                                        <th width="30%">Titulo</th>
                                        <th>Minimo</th>
                                        <th>Diario</th>
                                        <th>Semanal</th>
                                        <th>Inicia</th>
                                        <th>Vence</th>
                                        <th>Acci&oacute;n</th>
                                        </thead>
                                    </table>
                                    <a href="JavaScript:void(0)" onclick="offeraction('0', 'nulo');"><i class="fa fa-plus"></i> Oferta</a>
                                    <table  id="tbl_ofertas" name="tbl_ofertas" class="table table-responsive" widht="50%">
                                        <thead>
                                        <th>Promo</th>
                                        <th>Cantidad</th>
                                        <th>Inicia</th>
                                        <th>Vence</th>
                                        <th>Accion&nbsp;</th>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--<button type="submit" class="btn btn-danger">Enviar</button>-->
                </div>
        </form>
        <?php
        break;
    case 1:
        $stat = filter_input(INPUT_POST, "rent-status"); //ESTA activo
        $guardado = filter_input(INPUT_POST, "idsav"); //ESTA GUARDADO?
        $title = filter_input(INPUT_POST, "rent-title");
        $ref = filter_input(INPUT_POST, "rent-ref");
        $room = filter_input(INPUT_POST, "rent-room");
        $capacity = filter_input(INPUT_POST, "rent-capacity");
        $bathroom = filter_input(INPUT_POST, "rent-bathroom");
        $servi = filter_input(INPUT_POST, "rent-servicios");
        $type = filter_input(INPUT_POST, "rent-tipo");
        $mode = filter_input(INPUT_POST, "rent-modo");
        $place = filter_input(INPUT_POST, "rent-location");
        $address = filter_input(INPUT_POST, "rent-address");
        $lat = filter_input(INPUT_POST, "lat");
        $long = filter_input(INPUT_POST, "long");
        if ($guardado > 0) {
            $di = "update cms_property set title='$title', ref='$ref', room='$room', capacity='$capacity', bathroom='$bathroom', tipo='$type',"
                    . "modo='$mode', location='$place',servicios='$servi', address='$address', lat='$lat', longi='$long',status='$stat' where id=$guardado";
        } else {
            $di = "INSERT INTO cms_property(title,room,capacity,bathroom,servicios,tipo,modo,location,address,lat,longi,status)VALUES ('$title','$room','$capacity','$bathroom','$servi','$type','$mode','$place','$address','$lat','$long','$stat')";
        }
        $q = mysqli_query($CNN, $di) or $e = (mysqli_errno($CNN) . ": Error al guardar el alojamiento<br>" . mysqli_error($CNN) . "<br/>" . $di);
        if (!isset($e)) {
            if ($guardado >= 1) {
                $pid = $guardado;
            } else {
                $pid = mysqli_insert_id($CNN);
            }
            $req = 0;
            $arradons = array(); //se guardaran los datos de la bd
            $getsaves = mysqli_query($CNN, "select * from cms_property_addons where pid=$guardado"); //traemos lo que ya esta guardado
            while ($s = mysqli_fetch_array($getsaves)) {
                $arradons[$c['cid'] . "_" . $c['aid']] = $s['ovalue'];
            }
            $adonpid = "Insert into cms_property_addons(pid,cid,aid,ovalue)values"; //si no esta el addon en la base de datos
            $gtcat = mysqli_query($CNN, "select * from cms_catalog"); //traemos los catalogos
            while ($c = mysqli_fetch_array($gtcat)) {
                $gadd = mysqli_query($CNN, "select * from cms_addons where cid=" . $c['id'] . " and active=1"); //traemos los addons de cada catalogo
                while ($a = mysqli_fetch_array($gadd)) {
                    if (isset($_REQUEST[$c['id'] . "_" . $a['id']])) { //si recibimos el check
                        if (array_key_exists($c['id'] . "_" . $a['id'], $arradons)) { //preguntamos si ya estaba guardado//si si
                            if ($addons[$c['id'] . "_" . $a['id']] != $_REQUEST[$c['id'] . "_" . $a['id'] . "_data"]) { //preguntamos si es diferente el contenido
                                $upaddon = "update cms_property_addons set ovalue='" . $_REQUEST[$c['id'] . "_" . $a['id'] . "_data"] . "' where pid=$guard and cid={$c['id']} and aid={$a['id']};";
                            }
                        } else {//si no esta guardado
                            if (isset($_REQUEST[$c['id'] . "_" . $a['id'] . "_data"])) {
                                $data = $_REQUEST[$c['id'] . "_" . $a['id'] . "_data"];
                            } else {
                                $data = null;
                            }
                            $adonpid.="('$pid','" . $c['id'] . "','" . $a['id'] . "','$data'),";
                            $req++;
                        }
                    }
                }
            }
            if ($req >= 1) {
                $qy = substr($adonpid, 0, -1);
                $doadddon = mysqli_query($CNN, $qy)or $e = (mysqli_errno($CNN) . ": Error al guardar los catalogos del alojamiento<br>" . mysqli_error($CNN) . "<br/>" . $qy);
                if (!isset($e)) {
                    if ($_REQUEST["shlang"] >= 1) {
                        $upd = "update cms_property_translate";
                        foreach ($language as $o) {
                            $upd.="set cname='rent-short',lang='$o',caption='" . filter_input(INPUT_POST, "rent-short_" . $o) . "' where pid=$pid ;";
                        }
                    } else {
                        $nwla = "insert into cms_property_translate (pid,cname,lang,caption)values";
                        foreach ($language as $o) {
                            $nwla.="('$pid','rent-short','$o','" . filter_input(INPUT_POST, "rent-short_" . $o) . "' ),";
                        }
                    }
                    if ($_REQUEST["lonlang"] >= 1) {
                        foreach ($language as $o) {
                            $upd.="set cname='rent-large',lang='$o',caption='" . filter_input(INPUT_POST, "rent-large_" . $o) . "' where pid=$pid ;";
                        }
                    } else {
                        foreach ($language as $o) {
                            $nwla.="('$pid','rent-large','$o','" . filter_input(INPUT_POST, "rent-large_" . $o) . "' ),";
                        }
                    }
                    if (isset($upd)) {
                        if (mysqli_multi_query($CNN, $upd)) {
                            do {
                                if ($resu = mysqli_store_result($upd)) {
                                    while ($row = mysqli_fetch_row($resu)) {
                                        // printf("%s\n", $row[0]);
                                    }
                                    mysqli_free_result($resu);
                                }
                                if (mysqli_more_results($CNN)) {
                                    
                                }
                            } while (mysqli_next_result($CNN) && mysqli_more_results($CNN));
                        }
                    }
                    if (isset($nwla)) {
                        $nwla = substr($nwla, 0, - 1);
                        $ex = mysqli_query($CNN, $nwla)or $e = (mysqli_errno($CNN) . ": Error al guardar los lenguajes<br>" . mysqli_error($CNN) . "<br/>" . $nwla);
                    }
                    if (!isset($e)) {
                        ?><h4>
                            <div class="alert alert-success">
                                Se ha Guardo correctamente el alojamiento: <b><?php echo strtoupper($title); ?></b>
                            </div></h4>
                        <div class="btn btn-group-lg ">
                            <a href="./?m=property&s=housing&o=0" class="btn btn-warning" alt="Agregar Nuevo" title="Agregar Nuevo" ><i class="fa fa-chevron-left"></i> Agregar Otro alojamiento</a>
                            <a href="./?m=property&s=housing&o=2" class="btn btn-warning" alt="Ir al Listado" title="Ir al Listado" >Ir al Listado <i class="fa fa-chevron-right"></i></a>
                        </div>
                        <?php
                    } else {
                        ?><h4>
                            <div class="alert alert-warning">
                                <b><?php echo strtoupper($e); ?></b>
                            </div></h4>
                        <?php
                    }
                } else {
                    ?><h4>
                        <div class="alert alert-danger ">
                            Error al guardar <b><?php echo strtoupper($title); ?></b><br><?php echo $e; ?>
                        </div></h4>
                    <?php
                }
            } else {
                ?><h4>
                    <div class="alert alert-success">
                        Se ha Guardo correctamente el alojamiento: <b><?php echo strtoupper($title); ?></b>
                    </div></h4>
                <div class="btn btn-group-lg ">
                    <a href="./?m=property&s=housing&o=0" class="btn btn-warning" alt="Agregar Nuevo" title="Agregar Nuevo" ><i class="fa fa-chevron-left"></i> Agregar Otro alojamiento</a>
                    <a href="./?m=property&s=housing&o=2" class="btn btn-warning" alt="Ir al Listado" title="Ir al Listado" >Ir al Listado <i class="fa fa-chevron-right"></i></a>
                </div>
                <?php
            }
        } else {
            ?><h4>
                <div class="alert alert-warning">
                    <b><?php echo strtoupper($e); ?></b>
                </div></h4>
            <?php
        }
        break;
    case 2:
        ?>
        (<small>Administrar</small>)
        <table id="tbl_admin" class="table table-condensed">
            <thead>
                <tr>
                    <td width="1">ID</td>
                    <td>Titulo</td>
                    <td>Ref</td>
                    <td>Hab.</td>
                    <td>Capacidad</td>
                    <td width="1">Tipo</td>
                    <td>Modo</td>
                    <td>Status</td>
                    <td width="1">&nbsp;</td>
                </tr>
            </thead>
            <tbody style="align:center;"></tbody>
        </table>
        <!-----------------------TERMINA TABLA DINAMICA------------------->
        <!-----------------------INICIA SCRIPT DE LLAMADO A TABLA DINAMICA------------------->
        <script>
            $(document).ready(function () {
                jTable('tbl_admin', 'include/modules/property/property.table.php');
            });
        </script>
        <div class="modal fade" id="respuesta" name="respuesta" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" >
                <div class="modal-content" >
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="exampleModalLabel">Respuesta</h4>
                    </div>
                    <div class="modal-body" id="content_e" name="content_e">

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="mod_elim" name="mod_elim" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" >
                <div class="modal-content" >
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="exampleModalLabel">Eliminar</h4>
                    </div>
                    <div class="modal-body" id="elimina_c" name="elimina_c">
                        <form id='from_del_hous' name='from_del_hous' method='POST' >
                            <input type="text" name="op" id="op" value="70" class="hidden"/>
                            <input type="text" name="house_id" id="house_id" class="hidden"/>
                            <div class="form-group">
                                <label for="recipient-name" class="control-label">¿Esta seguro que desea eliminar?:</label>
                                <div id="texto" name="texto"></div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-success" onclick="delhouse();">Aceptar</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="clonehouse" name="clonehouse" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" >
                <div class="modal-content" >
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="exampleModalLabel">Clonar</h4>
                    </div>
                    <div class="modal-body" id="clon_h" name="clon_h">
                        <form id='clonhouse' name='clonhouse' method='POST' >
                            <input type="text" name="op" id="op" value="76" class="hidden"/>
                            <input type="text" name="clonid" id="clonid" value="" class="hidden"/>
                            <div class="form-group">
                                <label for="recipient-name" class="control-label">¿Esta seguro que desea clonar esta propiedad?:</label>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-warning" onclick="actionclon();">Clonar</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
        break;
    case 3:
        $id = $_REQUEST["id"];
        $info = array();
        $desc = array();
        $adds = array();
        $getinfo = "select * from cms_property where id=$id";
        $gf = mysqli_query($CNN, $getinfo) or $e = "ERROR #0: Error al traer los datos de la casa<br>consulte a su administrador<br>" . mysqli_error($CNN);
        if (!isset($e)) {
            while ($d = mysqli_fetch_array($gf)) {
                $info = $d;


                $getr = mysqli_query($CNN, "select * from cms_property_translate where pid=$id");
                while ($d = mysqli_fetch_array($getr)) {
                    $desc[$d['cname'] . "_" . $d['lang']] = $d['caption'];
                }
                $manlang = array();
                $coo = 0;
                $getr2 = mysqli_query($CNN, "select * from cms_property_translate where pid=$id group by lang");
                while ($d = mysqli_fetch_array($getr2)) {
                    $manlang[$coo] = $d['lang'];
                    $coo++;
                }
                $arrdif = array_diff($language, $manlang);
                if (count($arrdif) >= 1) {
                    $nwlang = "insert into cms_property_translate(pid,cname,lang)values";
                    foreach ($arrdif as $le) {
                        $nwlang.="('$id','rent-short','$le'),";
                        $nwlang.="('$id','rent-large','$le'),";
                    }
                    $nwlang = substr($nwlang, 0, -1);
                    $addnw = mysqli_query($CNN, $nwlang);
                    unset($desc);
                    $desc = array();
                    $getr = mysqli_query($CNN, "select * from cms_property_translate where pid=$id");
                    while ($d = mysqli_fetch_array($getr)) {
                        $desc[$d['cname'] . "_" . $d['lang']] = $d['caption'];
                    }
                }
                $geado = mysqli_query($CNN, "select * from cms_property_addons where pid=$id");
                $noro = mysqli_num_rows($geado);
                if ($noro >= 1) {
                    while ($a = mysqli_fetch_array($geado)) {
                        $adds[$a['cid'] . "_" . $a['aid'] . "_data"] = $a['ovalue'];
                    }
                } else {
                    $exq = "INSERT INTO cms_property_addons (cid, aid,ovalue,pid) SELECT a.cid,a.id,a.valor,'$id' AS pid  FROM cms_addons a WHERE required=1";
                    $inval = mysqli_query($CNN, $exq) or $err = "error al insertar los valores " . mysqli_error($CNN);
                    if (!isset($err)) {
                        $geado = mysqli_query($CNN, "select * from cms_property_addons where pid=$id");
                        while ($a = mysqli_fetch_array($geado)) {
                            $adds[$a['cid'] . "_" . $a['aid'] . "_data"] = $a['ovalue'];
                        }
                    }
                }
                ?>
                <h4><b><?php echo strtoupper($info['title']); ?></b><small>(editar)</small></h4>
                <form action="./?m=property&s=housing&o=1" method="post" class="form"name="formhousing" id="formhousing" enctype="multipart/form-data" >
                    <!---activo o inactivo-->
                    <div class="checkbox-1">
                        <br><br>
                        <span>Activo/Inactivo</span>
                        <input type="checkbox" id="ejemplo-1" value="<?php echo $info['status']; ?>" name="ejemplo-1"  class="hidden" onclick="status();"/>
                        <label for="ejemplo-1"></label>
                    </div>
                    <input type="number" value="0" id="rent-status" name="rent-status" class="hidden"><!---STATUS DE LA PROPIEDAD 0=INACTIVO / 1=ACTIVO---->
                    <input type="text" id="idsav" name="idsav" value="<?php echo $info['id']; ?>" class="hidden" ><!--ID DE PROPIDAD GUARDADA 0=GUARDADA/N=GUIARDADO--->
                    <input type="text" id="shlang" name="shlang" value="1" class="hidden" ><!--DESC CORTA 0=GUARDADA/N=GUARDADO--->
                    <input type="text" id="lonlang" name="lonlang" value="1" class="hidden" ><!--DESC LARGA 0=GUARDADA/N=GUARDADO--->
                    <div role="tabpanel">
                        <!---LISTADO DE PESTAÑAS--->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#informacion" aria-controls="informacion" role="tab" data-toggle="tab" class="text-uppercase">Informaci&oacute;n</a>
                            </li>
                            <?php
                            $nam_t = mysqli_query($CNN, "select * from cms_catalog");
                            while ($name = mysqli_fetch_array($nam_t)) {
                                ?>
                                <li role="presentation" class="text-uppercase">
                                    <a href="#<?php echo $name['id']; ?>" aria-controls="<?php echo $name['id']; ?>" role="tab" data-toggle="tab">
                                        <?php echo $name['common']; ?>
                                    </a>
                                </li>
                                <?php
                            }
                            ?>
                            <!-- <li role="presentation">
                                 <a href="#Precios" aria-controls="informacion" role="tab" onclick="checaguarda();" data-toggle="tab">Precios</a>
                             </li>-->
                        </ul>
                        <!--CONTENIDO DE LAS PESTAÑAS-->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active text-left " id="informacion" style="padding:1%;">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Nombre:</div>
                                                <input type="text"  id="rent-title" name="rent-title" value="<?php echo $info['title']; ?>" class="form-control input-lg text-uppercase" onchange="updatacampos(this.name, this.value);"  />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 ">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Referencia:</div>
                                                <input type="text" id="rent-ref" name="rent-ref" class="form-control input-lg text-uppercase" value="<?php echo $info['ref']; ?>" onchange="updatacampos(this.name, this.value);" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Modo:</div>
                                                <select id="rent-modo" name="rent-modo" class="form-control input-lg text-uppercase" onchange="updatacampos(this.name, this.value);" >
                                                    <option value="0" <?php
                                                    if ($info['modo'] == 0) {
                                                        echo "selected";
                                                    }
                                                    ?>>Alquiler</option>
                                                    <option value="1" <?php
                                                    if ($info['modo'] == 1) {
                                                        echo "selected";
                                                    }
                                                    ?>>Gestion</option>
                                                    <option value="2" <?php
                                                    if ($info['modo'] == 2) {
                                                        echo "selected";
                                                    }
                                                    ?>>Venta</option>
                                                    <option value="3" <?php
                                                    if ($info['modo'] == 3) {
                                                        echo "selected";
                                                    }
                                                    ?>>Traspaso</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Tipo:</div>
                                                <select id="rent-tipo" name="rent-tipo" class="form-control input-lg text-uppercase" onchange="updatacampos(this.name, this.value);" >
                                                    <?php
                                                    $typ = "SELECT * from cms_property_type ";
                                                    $slt = mysqli_query($CNN, $typ);
                                                    while ($x = mysqli_fetch_array($slt)) {
                                                        ?>
                                                        <option value='<?php echo $x['id']; ?>'<?php
                                                        if ($info['tipo'] == $x['id']) {
                                                            echo "selected";
                                                        }
                                                        ?>><?php echo $x['name']; ?></option>
                                                            <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Ba&ntilde;os:</div>
                                                <input type="number" id="rent-bathroom" name="rent-bathroom" value="<?php echo $info['bathroom']; ?>" min="0" class="form-control input-lg text-uppercase"  onblur="updatacampos(this.name, this.value);" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Servicios:</div>
                                                <input type="number" id="rent-servicios" name="rent-servicios"  value="<?php echo $info['servicios']; ?>" min="0" class="form-control input-lg text-uppercase" onblur="updatacampos(this.name, this.value);"  />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Habitaciones:</div>
                                                <input type="number" id="rent-room" name="rent-room" value="<?php echo $info['room']; ?>" min="0"class="form-control input-lg text-uppercase" onblur="updatacampos(this.name, this.value);" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Ocupantes:</div>
                                                <input type="number" id="rent-capacity" name="rent-capacity" value="<?php echo $info['capacity']; ?>" min="0" class="form-control input-lg text-uppercase" onblur="updatacampos(this.name, this.value);" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-addon">Ubicacion:</div>
                                                    <select id="rent-location" name="rent-location" class="form-control input-lg text-uppercase" onblur="updatacampos(this.name, this.value);"  >
                                                        <?php
                                                        $consulta = "SELECT * from cms_property_locale ";
                                                        $result = mysqli_query($CNN, $consulta);
                                                        while ($x = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                                                            ?>
                                                            <option value='<?php echo $x['id']; ?>'<?php
                                                            if ($info['location'] == $x['id']) {
                                                                echo "selected";
                                                            }
                                                            ?>><?php echo $x['name']; ?></value>
                                                                    <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class=row>
                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-addon">Direcci&oacute;n:</div>
                                                            <input type="text" id="rent-address" name="rent-address"  value="<?php echo $info['address']; ?>"class="form-control input-lg text-uppercase" onkeypress="clearmapa();mapadire(this.value);" onblur="updatacampos(this.name, this.value);" />
                                                            <input type="text" id="dirho_num" value="0" class="hidden">
                                                        </div>
                                                    </div>
                                                </div>
                                                <!----INICIAN LAS TRADUCCIONES--->
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div>
                                                            <ul class="nav nav-tabs" role="tablist">
                                                                <?php
                                                                foreach ($language as $L) {
                                                                    ?>
                                                                    <li role="presentation" class="<?php
                                                                    if ($L == "es") {
                                                                        echo "active";
                                                                    }
                                                                    ?>">
                                                                        <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab" class="text-uppercase">
                                                                            <?php echo $L; ?>
                                                                            <?php if ($L == "es") { ?>
                                                                                <span class="label label-danger">Requerido</span>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </a>
                                                                    </li>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </ul>
                                                            <div class="tab-content">
                                                                <?php
                                                                foreach ($language as $L) {
                                                                    ?>
                                                                    <div role="tabpanel" class="tab-pane  <?php
                                                                    if ($L == "es") {
                                                                        echo "active";
                                                                    }
                                                                    ?> " id="tab_<?php echo $L; ?>">
                                                                        <br>
                                                                        <div class="row ">
                                                                            <div class="col-lg-12">
                                                                                <div class="form-group">
                                                                                    <div class="input-group">
                                                                                        <div class="input-group-addon">Descripci&oacute;n Corta<small><?php echo "(" . $L . ")"; ?></small></div>
                                                                                        <input type="text" id="rent-short_<?php echo $L; ?>" value="<?php echo $desc["rent-short_" . $L] ?>" name="rent-short_<?php echo $L; ?>"  size="200" class="form-control input-lg text-uppercase" onblur="saveshort(this.name, this.value);"  />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-12">
                                                                                <div class="form-group">
                                                                                    <div class="input-group">
                                                                                        <div class="input-group-addon">Descripci&oacute;n Larga<small><?php echo "(" . $L . ")"; ?></small></div>
                                                                                        <textarea type="text" id="rent-large_<?php echo $L; ?>" name="rent-large_<?php echo $L; ?>" rows="6" cols="100%" class="form-control input-lg text-uppercase" onblur="savelong(this.name, this.value);" /><?php echo $desc["rent-large_" . $L] ?></textarea>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6"><!---Aqui va el mapa--->
                                        <div id="test" class="gmap3"></div>
                                        <input type="text" name="lat" id="lat" value="0" class="hidden"><!--latitud-->
                                        <input type="text" name="long" id="long" value="0"class="hidden" ><!---Longitud--->
                                    </div>
                                </div>
                            </div>
                            <!-- Dinamico -->
                            <?php
                            $gettabs = mysqli_query($CNN, "select * from cms_catalog");
                            while ($p = mysqli_fetch_array($gettabs)) {
                                ?>
                                <div role="tabpanel" class="tab-pane" id="<?php echo $p['id']; ?>" name="<?php echo $p['id']; ?>" style="padding:1%;">
                                    <?php
                                    $addons = "SELECT a.caption,b.* FROM  cms_addon_translate a INNER JOIN cms_addons b ON (a.aid=b.id) WHERE tname='{$p['id']}' AND lang='es'";
                                    $ado = mysqli_query($CNN, $addons) or $err = "error al traer el catalogo <b>{$p['common']}<b><br>" . mysqli_error($CNN);
                                    if (!isset($err)) {
                                        $ro = 0;
                                        while ($r = mysqli_fetch_array($ado)) {
                                            unset($val);
                                            if (array_key_exists($p['id'] . "_" . $r["id"] . "_data", $adds)) {
                                                $ck = "checked data-save='1'";
                                                $val = $adds[$p['id'] . "_" . $r["id"] . "_data"];
                                            } else {
                                                $val = null;
                                                $ck = "data-save='0'";
                                            }
                                            $chked = $chked2 = "";
                                            if ($val == 1) {
                                                $chked = "checked";
                                            }
                                            if ($val == 0) {
                                                $chked2 = "checked";
                                            }
                                            $req = null;
                                            unset($idimpt);
                                            $idimpt = $p['id'] . "_" . $r['id'];
                                            if ($r['required'] == 1) {
                                                $req = 'checked="checked"  readonly="readonly" onclick="javascript: return false;"';
                                            } else {
                                                $req = 'onclick="saveitem(' . $p['id'] . ',' . $r['id'] . ');"';
                                            }
                                            if ($ro == 0) {
                                                ?>
                                                <div class="row">
                                                    <?php
                                                }
                                                $ro++;
                                                ?>
                                                <div class="col-lg-4">
                                                    <table class="table table-bordered table-hover">
                                                        <tr >
                                                            <td widht="1" style="vertical-align: middle; ">
                                                                <input type="checkbox" class="input-lg "  id="<?php echo $idimpt; ?>" value="<?php echo $r['id']; ?>" <?php echo $req . $ck; ?> />
                                                            </td>
                                                            <td widht="49%" style="vertical-align: middle; ">
                                                                <?php echo strtoupper(utf8_decode($r['caption'])); ?>
                                                            </td>
                                                            <td width="50%" style="vertical-align: middle; ">
                                                                <?php
                                                                switch (($r['tipo'])) {
                                                                    case 0:
                                                                        ?>
                                                                        <input type="radio" id="<?php echo $idimpt; ?>_data" name="<?php echo $idimpt; ?>_data" value="1" onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, 1);" <?php echo $chked; ?>>Si
                                                                        <input type="radio" id="<?php echo $idimpt; ?>_data" class="input-lg text-uppercase" name="<?php echo $idimpt; ?>_data" value="0" onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, 0);" <?php echo $chked2; ?>>No
                                                                        <?php
                                                                        break;
                                                                    case 1:
                                                                        ?>
                                                                        <input type="number" id="<?php echo $idimpt; ?>_data" value="<?php echo $val; ?>" class="form-control input-lg text-uppercase"  onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);"/>
                                                                        <?php
                                                                        break;
                                                                    case 2:
                                                                        ?>
                                                                        <input type="text"id="<?php echo $idimpt; ?>_data"  value="<?php echo $val; ?>" class="form-control input-lg text-uppercase"  placeholder="Text"  onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);"/>
                                                                        <?php
                                                                        break;
                                                                }
                                                                ?>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <?php
                                                if ($ro == 3) {
                                                    $ro = 0;
                                                    ?>
                                                </div>
                                                <?php
                                            }
                                        }
                                        if ($ro <= 3) {
                                            ?>
                                        </div><?php
                                    }
                                } else {
                                    ?>
                                    <div class="alert alert-danger">
                                        <?php echo $err; ?>
                                    </div>
                                    <?php
                                    unset($err);
                                }
                                ?>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </form>
                <script>
                    $(document).ready(function () {
                        cargamapa();
                    });
                </script>
                <?php
            }
        } else {
            ?>
            <div class="alert alert-danger ">
                <?php strtoupper($e); ?>
            </div>
            <?php
        }
        break;
    case 4: //:::::::::::::::::::::::GUARDA ACTUALIZACION
        $title = filter_input(INPUT_POST, "rent-title");
        $ref = filter_input(INPUT_POST, "rent-ref");
        $room = filter_input(INPUT_POST, "rent-room");
        $capacity = filter_input(INPUT_POST, "rent-capa");
        $bathroom = filter_input(INPUT_POST, "rent-bat");
        $serv = filter_input(INPUT_POST, "rent-serv");
        $type = filter_input(INPUT_POST, "rent-type");
        $mode = filter_input(INPUT_POST, "rent-mode");
        $place = filter_input(INPUT_POST, "rent-ubi");
        $short = filter_input(INPUT_POST, "rent-short");
        $large = filter_input(INPUT_POST, "rent-large");
        $dire = filter_input(INPUT_POST, "rent-address");
        $lat = filter_input(INPUT_POST, "lat");
        $long = filter_input(INPUT_POST, "long");
        $sta = filter_input(INPUT_POST, "rent-status");
        $id = $_REQUEST['id'];
        $cinsert = 0;
        $erroresgral = 0;
        $updaprop = mysqli_query($CNN, "UPDATE cms_property SET title = '$title', address='$dire',status='$sta',lat='$lat',servicios='$serv',longi='$long', ref = '$ref', room= '$room', capacity = '$capacity',  tipo = '$type',  modo = '$mode',  location = '$place',  short_desc = '$short',  long_desc = '$large',  bathroom = '$bathroom' WHERE id = '$id'")or $texerror = "<br/>#0 " . mysqli_error($CNN);
        if (!isset($texerror)) {
            ?><!--<h4>Informacion general actualizada correctamente</h4>--><?php
            $cole = array("general", "interior", "exterior", "equip");
            $dp = array('gen_', 'in_', 'out_', 'equi_');
            for ($i = 0; $i < count($cole); $i++) {
                unset($git, $eqry);
                //:::::::::::::::::::::::::ACTUALIZA Y/O ELIMINA LOS QUE  YA EXISTEN EN LA TABLA
                $eqry = "SELECT a.id, b.ovalue FROM cms_property_{$cole[$i]} a INNER JOIN cms_property_e_{$cole[$i]} b ON (a.id=b.oid) WHERE a.active=1 AND b.pid=$id";
                $git = mysqli_query($CNN, $eqry) or $errg = "#$i Error {$cole[$i]}" . mysqli_error($CNN);
                if (!isset($errg)) {
                    $upd = "";
                    while ($f = mysqli_fetch_array($git)) {
                        $cas = $dp[$i] . $f['id'];
                        if (isset($_REQUEST[$cas])) {
                            $cvalue = $dp[$i] . $f['id'] . "_data";
                            $valc = filter_input(INPUT_POST, $cvalue);
                            if ($valc != $f['ovalue']) {
                                $upd.="update cms_property_e_{$cole[$i]} set ovalue='" . filter_input(INPUT_POST, $cvalue) . "' where oid={$f['id']} and pid=$id;";
                                $cinsert++;
                            }
                        } else {
                            $upd.="delete from cms_property_e_{$cole[$i]} where oid={$f['id']} and pid=$id; ";
                            $cinsert++;
                        }
                        $cvalue = $valc = "";
                    }
                } else {
                    ?><h4><?php echo $errg; ?></h4><?php
                    $erroresgral++;
                    unset($errg);
                }
                //:::::::::::::::::::::::INSERTA LOS QUE NO ESTAN EN LA TABLA
                $myqr2 = "SELECT a.* FROM cms_property_{$cole[$i]} a WHERE a.id NOT IN(SELECT oid FROM cms_property_e_{$cole[$i]} where pid=$id) and a.active=1";
                $grest = mysqli_query($CNN, $myqr2)or $errq2 = "Error #$i :" . mysqli_error($CNN);
                if (!isset($errq2)) {
                    while ($f = mysqli_fetch_array($grest)) {
                        $cas = $dp[$i] . $f['id'];
                        if (isset($_REQUEST[$cas])) {
                            $cvalue = $dp[$i] . $f['id'] . "_data";
                            $valc = filter_input(INPUT_POST, $cvalue);
                            $upd.="insert into cms_property_e_{$cole[$i]} (pid,oid,ovalue)values('$id','{$f['id']}','" . filter_input(INPUT_POST, $cvalue) . "');";
                            $cinsert++;
                        }
                        $cvalue = $valc = "";
                    }
                } else {
                    ?><h4><?php echo $errq2; ?></h4><?php
                    $erroresgral++;
                }
                echo "<div class='hidden'>" . utf8_encode($upd) . "</div>";
                if ($cinsert > 0) {
                    $insall = mysqli_multi_query($CNN, $upd) or $errall = "error al insertar $cole[$i]: " . mysqli_error($CNN);
                    if (!isset($errall)) {
                        $upd = null;
                        ?><h4><?php echo $cole[$i]; ?> Actualizado correctamente</h4> <?php
                        unset($insall);
                    } else {
                        ?><h4><?php echo $errall; ?></h4><?php
                        $erroresgral++;
                    }
                }
            }
        } else {
            echo $texerror;
        }
        if ($erroresgral == 0) {
            ?>
            <h2> <label class="label label-primary"><li class="fa fa-hand-o-right"> PROPIEDAD GUARDADA CON &Eacute;XITO</li></label></h2>
            <div class="input-group">
                <a href="./?m=property&s=housing&o=0" class="btn btn-info" >Agregar Propiedad</a>
                <a href="./?m=property&s=housing&o=2" class="btn btn-success" >Regresar al Listado</a>
            </div>
            <?php
        }
        break;
    case 7:
        /* if (isset($_REQUEST["id"])) {
          $id = $_REQUEST["id"];
          ?><i class="fa fa-picture-o"></i><label>Galer&iacute;a</label><br><?php
          $traedatos = mysqli_query($CNN, "SELECT p.*,b.name as dest FROM cms_property p INNER JOIN cms_property_locale b ON (p.location=b.`id`) WHERE p.id=$id");
          while ($h = mysqli_fetch_array($traedatos)) {
          echo "<small><b>" . strtoupper($h['title']) . "</small>";
          }
          } else {
          $id = 0;
          }
          ?>
          <div id="frmPost" class="dropzone"></div>
          <div id="gallery_show" name="gallery_show"></div>
          <script>
          var dz = $("#frmPost").dropzone({
          maxFilesize: 200,
          url: "content/upload/property/upload.inc.php?id=<?php echo $id; ?>",
          complete: function (file) {
          console.log(file);
          $.ajax({
          method: "POST",
          url: "include/modules/property/gallery.ajax.php",
          data: {"id": "<?php echo $id; ?>"}
          }).done(function (data) {
          $("#gallery_show").html(data);
          });
          }
          });
          $(document).ready(function ()
          {
          $.ajax({
          method: "POST",
          url: "include/modules/property/gallery.ajax.php",
          data: {"id": "<?php echo $id; ?>"}
          }).done(function (data) {
          $("#gallery_show").html(data);
          });
          });
          </script>
          <div class="modal fade" id="mod_elim" name="mod_elim" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" >
          <div class="modal-content" >
          <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="exampleModalLabel">Eliminar</h4>
          </div>
          <div class="modal-body" id="elimina_c" name="elimina_c">
          <form id='form_elim' name='form_elim' method='POST' >
          <input type="text" name="op" id="op" value="80" class="hidden"/>
          <input type="text" name="elim_id" id="elim_id" class="hidden"/>
          <input type="text" value="<?php echo $id; ?>"name="prop_id" id="prop_id" class="hidden"/>
          <div class="form-group">
          <label for="recipient-name" class="control-label">¿Esta seguro que desea eliminar la imagen?:</label>
          <div id="tit" name="tit"></div>
          <input type="text" name="el_id" class="form-control" id="el_id" class="hidden"/>
          </div>
          </form>
          </div>
          <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
          <button type="button" class="btn btn-success" id="aceptar" name="aceptar" onclick="eliminaitemimage(<?php echo $id; ?>);">Aceptar</button>
          </div>
          </div>
          </div>
          </div>
          <?php
         */
        break;
    case 10:
        $id = $_REQUEST["id"];
        $info = array();
        $desc = array();
        $adds = array();
        $getinfo = "select * from cms_property where id=$id";
        $gf = mysqli_query($CNN, $getinfo) or $e = "ERROR #0: Error al traer los datos de la casa<br>consulte a su administrador<br>" . mysqli_error($CNN);
        if (!isset($e)) {
            while ($d = mysqli_fetch_array($gf)) {
                $info = $d;


                $getr = mysqli_query($CNN, "select * from cms_property_translate where pid=$id");
                while ($d = mysqli_fetch_array($getr)) {
                    $desc[$d['cname'] . "_" . $d['lang']] = $d['caption'];
                }
                $manlang = array();
                $coo = 0;
                $getr2 = mysqli_query($CNN, "select * from cms_property_translate where pid=$id group by lang");
                while ($d = mysqli_fetch_array($getr2)) {
                    $manlang[$coo] = $d['lang'];
                    $coo++;
                }
                $arrdif = array_diff($language, $manlang);
                if (count($arrdif) >= 1) {
                    $nwlang = "insert into cms_property_translate(pid,cname,lang)values";
                    foreach ($arrdif as $le) {
                        $nwlang.="('$id','rent-short','$le'),";
                        $nwlang.="('$id','rent-large','$le'),";
                    }
                    $nwlang = substr($nwlang, 0, -1);
                    $addnw = mysqli_query($CNN, $nwlang);
                    unset($desc);
                    $desc = array();
                    $getr = mysqli_query($CNN, "select * from cms_property_translate where pid=$id");
                    while ($d = mysqli_fetch_array($getr)) {
                        $desc[$d['cname'] . "_" . $d['lang']] = $d['caption'];
                    }
                }
                $geado = mysqli_query($CNN, "select * from cms_property_addons where pid=$id");
                $noro = mysqli_num_rows($geado);
                if ($noro >= 1) {
                    while ($a = mysqli_fetch_array($geado)) {
                        $adds[$a['cid'] . "_" . $a['aid'] . "_data"] = $a['ovalue'];
                    }
                } else {
                    $exq = "INSERT INTO cms_property_addons (cid, aid,ovalue,pid) SELECT a.cid,a.id,a.valor,'$id' AS pid  FROM cms_addons a WHERE required=1";
                    $inval = mysqli_query($CNN, $exq) or $err = "error al insertar los valores " . mysqli_error($CNN);
                    if (!isset($err)) {
                        $geado = mysqli_query($CNN, "select * from cms_property_addons where pid=$id");
                        while ($a = mysqli_fetch_array($geado)) {
                            $adds[$a['cid'] . "_" . $a['aid'] . "_data"] = $a['ovalue'];
                        }
                    }
                }
                ?>
                <h4><b><?php echo strtoupper($info['title']); ?></b><small>(editar)</small></h4>
                <form action="./?m=property&s=housing&o=1" method="post" class="form"name="formhousing" id="formhousing" enctype="multipart/form-data" >
                    <!---activo o inactivo-->
                    <div class="checkbox-1">
                        <br><br>
                        <span>Activo/Inactivo</span>
                        <input type="checkbox" id="ejemplo-1" value="<?php echo $info['status']; ?>" name="ejemplo-1"  class="hidden" onclick="status();"/>
                        <label for="ejemplo-1"></label>
                    </div>
                    <input type="number" value="0" id="rent-status" name="rent-status" class="hidden"><!---STATUS DE LA PROPIEDAD 0=INACTIVO / 1=ACTIVO---->
                    <input type="text" id="idsav" name="idsav" value="<?php echo $info['id']; ?>" class="hidden" ><!--ID DE PROPIDAD GUARDADA 0=GUARDADA/N=GUIARDADO--->
                    <input type="text" id="shlang" name="shlang" value="1" class="hidden" ><!--DESC CORTA 0=GUARDADA/N=GUARDADO--->
                    <input type="text" id="lonlang" name="lonlang" value="1" class="hidden" ><!--DESC LARGA 0=GUARDADA/N=GUARDADO--->
                    <div role="tabpanel">
                        <!---LISTADO DE PESTAÑAS--->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#informacion" aria-controls="informacion" role="tab" data-toggle="tab" class="text-uppercase">Informaci&oacute;n</a>
                            </li>
                            <?php
                            $nam_t = mysqli_query($CNN, "select * from cms_catalog");
                            while ($name = mysqli_fetch_array($nam_t)) {
                                ?>
                                <li role="presentation" class="text-uppercase">
                                    <a href="#<?php echo $name['id']; ?>" aria-controls="<?php echo $name['id']; ?>" role="tab" data-toggle="tab">
                                        <?php echo $name['common']; ?>
                                    </a>
                                </li>
                                <?php
                            }
                            ?>
                            <!-- <li role="presentation">
                                 <a href="#Precios" aria-controls="informacion" role="tab" onclick="checaguarda();" data-toggle="tab">Precios</a>
                             </li>-->
                        </ul>
                        <!--CONTENIDO DE LAS PESTAÑAS-->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active text-left " id="informacion" style="padding:1%;">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Nombre:</div>
                                                <input type="text"  id="rent-title" name="rent-title" value="<?php echo $info['title']; ?>" class="form-control input-lg text-uppercase" onchange="updatacampos(this.name, this.value);"  />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 ">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Referencia:</div>
                                                <input type="text" id="rent-ref" name="rent-ref" class="form-control input-lg text-uppercase" value="<?php echo $info['ref']; ?>" onchange="updatacampos(this.name, this.value);" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Modo:</div>
                                                <select id="rent-modo" name="rent-modo" class="form-control input-lg text-uppercase" onchange="updatacampos(this.name, this.value);" >
                                                    <option value="0" <?php
                                                    if ($info['modo'] == 0) {
                                                        echo "selected";
                                                    }
                                                    ?>>Alquiler</option>
                                                    <option value="1" <?php
                                                    if ($info['modo'] == 1) {
                                                        echo "selected";
                                                    }
                                                    ?>>Gestion</option>
                                                    <option value="2" <?php
                                                    if ($info['modo'] == 2) {
                                                        echo "selected";
                                                    }
                                                    ?>>Venta</option>
                                                    <option value="3" <?php
                                                    if ($info['modo'] == 3) {
                                                        echo "selected";
                                                    }
                                                    ?>>Traspaso</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Tipo:</div>
                                                <select id="rent-tipo" name="rent-tipo" class="form-control input-lg text-uppercase" onchange="updatacampos(this.name, this.value);" >
                                                    <?php
                                                    $typ = "SELECT * from cms_property_type ";
                                                    $slt = mysqli_query($CNN, $typ);
                                                    while ($x = mysqli_fetch_array($slt)) {
                                                        ?>
                                                        <option value='<?php echo $x['id']; ?>'<?php
                                                        if ($info['tipo'] == $x['id']) {
                                                            echo "selected";
                                                        }
                                                        ?>><?php echo $x['name']; ?></option>
                                                            <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Ba&ntilde;os:</div>
                                                <input type="number" id="rent-bathroom" name="rent-bathroom" value="<?php echo $info['bathroom']; ?>" min="0" class="form-control input-lg text-uppercase"  onblur="updatacampos(this.name, this.value);" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Servicios:</div>
                                                <input type="number" id="rent-servicios" name="rent-servicios"  value="<?php echo $info['servicios']; ?>" min="0" class="form-control input-lg text-uppercase" onblur="updatacampos(this.name, this.value);"  />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Habitaciones:</div>
                                                <input type="number" id="rent-room" name="rent-room" value="<?php echo $info['room']; ?>" min="0"class="form-control input-lg text-uppercase" onblur="updatacampos(this.name, this.value);" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-addon">Ocupantes:</div>
                                                <input type="number" id="rent-capacity" name="rent-capacity" value="<?php echo $info['capacity']; ?>" min="0" class="form-control input-lg text-uppercase" onblur="updatacampos(this.name, this.value);" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-addon">Ubicacion:</div>
                                                    <select id="rent-location" name="rent-location" class="form-control input-lg text-uppercase" onblur="updatacampos(this.name, this.value);"  >
                                                        <?php
                                                        $consulta = "SELECT * from cms_property_locale ";
                                                        $result = mysqli_query($CNN, $consulta);
                                                        while ($x = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                                                            ?>
                                                            <option value='<?php echo $x['id']; ?>'<?php
                                                            if ($info['location'] == $x['id']) {
                                                                echo "selected";
                                                            }
                                                            ?>><?php echo $x['name']; ?></value>
                                                                    <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class=row>
                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-addon">Direcci&oacute;n:</div>
                                                            <input type="text" id="rent-address" name="rent-address"  value="<?php echo $info['address']; ?>"class="form-control input-lg text-uppercase" onkeypress="clearmapa();mapadire(this.value);" onblur="updatacampos(this.name, this.value);" />
                                                            <input type="text" id="dirho_num" value="0" class="hidden">
                                                        </div>
                                                    </div>
                                                </div>
                                                <!----INICIAN LAS TRADUCCIONES--->
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div>
                                                            <ul class="nav nav-tabs" role="tablist">
                                                                <?php
                                                                foreach ($language as $L) {
                                                                    ?>
                                                                    <li role="presentation" class="<?php
                                                                    if ($L == "es") {
                                                                        echo "active";
                                                                    }
                                                                    ?>">
                                                                        <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab" class="text-uppercase">
                                                                            <?php echo $L; ?>
                                                                            <?php if ($L == "es") { ?>
                                                                                <span class="label label-danger">Requerido</span>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </a>
                                                                    </li>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </ul>
                                                            <div class="tab-content">
                                                                <?php
                                                                foreach ($language as $L) {
                                                                    ?>
                                                                    <div role="tabpanel" class="tab-pane  <?php
                                                                    if ($L == "es") {
                                                                        echo "active";
                                                                    }
                                                                    ?> " id="tab_<?php echo $L; ?>">
                                                                        <br>
                                                                        <div class="row ">
                                                                            <div class="col-lg-12">
                                                                                <div class="form-group">
                                                                                    <div class="input-group">
                                                                                        <div class="input-group-addon">Descripci&oacute;n Corta<small><?php echo "(" . $L . ")"; ?></small></div>
                                                                                        <input type="text" id="rent-short_<?php echo $L; ?>" value="<?php echo $desc["rent-short_" . $L] ?>" name="rent-short_<?php echo $L; ?>"  size="200" class="form-control input-lg text-uppercase" onblur="saveshort(this.name, this.value);"  />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-12">
                                                                                <div class="form-group">
                                                                                    <div class="input-group">
                                                                                        <div class="input-group-addon">Descripci&oacute;n Larga<small><?php echo "(" . $L . ")"; ?></small></div>
                                                                                        <textarea type="text" id="rent-large_<?php echo $L; ?>" name="rent-large_<?php echo $L; ?>" rows="6" cols="100%" class="form-control input-lg text-uppercase" onblur="savelong(this.name, this.value);" /><?php echo $desc["rent-large_" . $L] ?></textarea>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6"><!---Aqui va el mapa--->
                                        <div id="test" class="gmap3"></div>
                                        <input type="text" name="lat" id="lat" value="0" class="hidden"><!--latitud-->
                                        <input type="text" name="long" id="long" value="0"class="hidden" ><!---Longitud--->
                                    </div>
                                </div>
                            </div>
                            <!-- Dinamico -->
                            <?php
                            $gettabs = mysqli_query($CNN, "select * from cms_catalog");
                            while ($p = mysqli_fetch_array($gettabs)) {
                                ?>
                                <div role="tabpanel" class="tab-pane" id="<?php echo $p['id']; ?>" name="<?php echo $p['id']; ?>" style="padding:1%;">
                                    <?php
                                    $addons = "SELECT a.caption,b.* FROM  cms_addon_translate a INNER JOIN cms_addons b ON (a.aid=b.id) WHERE tname='{$p['id']}' AND lang='es'";
                                    $ado = mysqli_query($CNN, $addons) or $err = "error al traer el catalogo <b>{$p['common']}<b><br>" . mysqli_error($CNN);
                                    if (!isset($err)) {
                                        $ro = 0;
                                        while ($r = mysqli_fetch_array($ado)) {
                                            unset($val);
                                            if (array_key_exists($p['id'] . "_" . $r["id"] . "_data", $adds)) {
                                                $ck = "checked data-save='1'";
                                                $val = $adds[$p['id'] . "_" . $r["id"] . "_data"];
                                            } else {
                                                $val = null;
                                                $ck = "data-save='0'";
                                            }
                                            $chked = $chked2 = "";
                                            if ($val == 1) {
                                                $chked = "checked";
                                            }
                                            if ($val == 0) {
                                                $chked2 = "checked";
                                            }
                                            $req = null;
                                            unset($idimpt);
                                            $idimpt = $p['id'] . "_" . $r['id'];
                                            if ($r['required'] == 1) {
                                                $req = 'checked="checked"  readonly="readonly" onclick="javascript: return false;"';
                                            } else {
                                                $req = 'onclick="saveitem(' . $p['id'] . ',' . $r['id'] . ');"';
                                            }
                                            if ($ro == 0) {
                                                ?>
                                                <div class="row">
                                                    <?php
                                                }
                                                $ro++;
                                                ?>
                                                <div class="col-lg-4">
                                                    <table class="table table-bordered table-hover">
                                                        <tr >
                                                            <td widht="1" style="vertical-align: middle; ">
                                                                <input type="checkbox" class="input-lg "  id="<?php echo $idimpt; ?>" value="<?php echo $r['id']; ?>" <?php echo $req . $ck; ?> />
                                                            </td>
                                                            <td widht="49%" style="vertical-align: middle; ">
                                                                <?php echo strtoupper(utf8_decode($r['caption'])); ?>
                                                            </td>
                                                            <td width="50%" style="vertical-align: middle; ">
                                                                <?php
                                                                switch (($r['tipo'])) {
                                                                    case 0:
                                                                        ?>
                                                                        <input type="radio" id="<?php echo $idimpt; ?>_data" name="<?php echo $idimpt; ?>_data" value="1" onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, 1);" <?php echo $chked; ?>>Si
                                                                        <input type="radio" id="<?php echo $idimpt; ?>_data" class="input-lg text-uppercase" name="<?php echo $idimpt; ?>_data" value="0" onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, 0);" <?php echo $chked2; ?>>No
                                                                        <?php
                                                                        break;
                                                                    case 1:
                                                                        ?>
                                                                        <input type="number" id="<?php echo $idimpt; ?>_data" value="<?php echo $val; ?>" class="form-control input-lg text-uppercase"  onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);"/>
                                                                        <?php
                                                                        break;
                                                                    case 2:
                                                                        ?>
                                                                        <input type="text"id="<?php echo $idimpt; ?>_data"  value="<?php echo $val; ?>" class="form-control input-lg text-uppercase"  placeholder="Text"  onblur="save_value(<?php echo $p['id'] . ',' . $r['id']; ?>, this.value);"/>
                                                                        <?php
                                                                        break;
                                                                }
                                                                ?>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <?php
                                                if ($ro == 3) {
                                                    $ro = 0;
                                                    ?>
                                                </div>
                                                <?php
                                            }
                                        }
                                        if ($ro <= 3) {
                                            ?>
                                        </div><?php
                                    }
                                } else {
                                    ?>
                                    <div class="alert alert-danger">
                                        <?php echo $err; ?>
                                    </div>
                                    <?php
                                    unset($err);
                                }
                                ?>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </form>
                <script>
                    $(document).ready(function () {
                        cargamapa();
                    });
                </script>
                <?php
            }
        } else {
            ?>
            <div class="alert alert-danger ">
                <?php strtoupper($e); ?>
            </div>
            <?php
        }
        break;
    case 11:
        $errstr = "";
        $title = filter_input(INPUT_POST, "rent-title");
        $prize = filter_input(INPUT_POST, "rent-prize");
        $room = filter_input(INPUT_POST, "rent-room");
        $capacity = filter_input(INPUT_POST, "rent-capa");
        $bathroom = filter_input(INPUT_POST, "rent-bat");
        $type = filter_input(INPUT_POST, "rent-type");
        $mode = filter_input(INPUT_POST, "rent-mode");
        $place = filter_input(INPUT_POST, "rent-ubi");
        $short = filter_input(INPUT_POST, "rent-short");
        $large = filter_input(INPUT_POST, "rent-large");
        $meta = substr(filter_input(INPUT_POST, "rent-meta"), 0, -1);
        $address = filter_input(INPUT_POST, "rent-address");
        $seo = filter_input(INPUT_POST, "rent-seo");
        $oSQL = "INSERT INTO cms_property(title,prize,room,capacity,bathroom,tipo,modo,location,short_desc,long_desc,metadatos,seo,address)VALUES ('$title','$prize','$room','$capacity','$bathroom','$type','$mode','$place','$short','$large','$meta','$seo','$address')";
        $q = mysqli_query($CNN, $oSQL) or $e = (mysqli_errno($CNN) . ":" . mysqli_error($CNN) . "<br/>" . $oSQL);
        ///* ### SECUNDARIO ###
        $arr = array('interior', 'exterior', 'equip', 'general');
        $pre = array('in', 'out', 'equi', 'gen');
        if (!isset($e)) {
            ?>
            <h3>Se ha dado de alta la informaci&oacute;n general de la propiedad</h3>
            <?php
            $id = mysqli_insert_id($CNN);
            $f2 = 0;
            for ($i = 0; $i < count($arr); $i++) {

                $mysq2 = "SELECT a.* FROM cms_property_{$arr[$i]} a WHERE a.active=1";
                $sq2 = mysqli_query($CNN, $mysq2) or $eex = mysqli_errno($CNN) . ": " . mysqli_error($CNN);
                if (!isset($eex)) {
                    $insernew = "insert into cms_property_e_{$arr[$i]} (pid, oid,ovalue) values";
                    while ($t = mysqli_fetch_array($sq2)) {
                        $fld = $pre[$i] . "_" . $t['id'];
                        if (isset($_REQUEST[$fld])) {
                            $data = $pre[$i] . "_" . $t['id'] . "_data";
                            $valdata = filter_input(INPUT_POST, $data);
                            $val = $valdata;
                            if ($valdata == "") {
                                $val = null;
                            }
                            $insernew.="('$id','{$t['id']}','$val'),";
                            $f2++;
                        }
                        $fld = "";
                        $data = "";
                        $val = "";
                    }
                    $insernew = substr($insernew, 0, -1);
                    $insernew.=";";
                    if ($f2 > 0) { //solo si hay algun error
                        $in = mysqli_query($CNN, $insernew) or $errx = mysqli_errno($CNN) . ":" . mysqli_error($CNN) . "<br/>" . $insernew;
                        if (!isset($err)) {
                            ?>
                            <div class="alert alert-success">
                                <h4>Se ha guardado la informaci&oacute;n para el cat&aacute;logo <?php echo $arr[$i]; ?></h4>
                            </div>
                            <?php
                        } else {
                            ?>
                            <div class="well well-sm" >
                                Lo sentimos, ocurri&oacute; un error con el cat&aacute;logo <?php echo $arr[$i]; ?><br>
                                ERROR <?php echo ($i + 1); ?><br/>
                                CODE:#<?php echo $errx; ?><br/>
                                <button name="regresa" class="btn btn-danger" onclick="window.history.go(-1);
                                        return false;"> Regresar </button>
                            </div>
                            <?php
                        }
                    }
                } else {
                    ?>
                    <div class="well well-sm" >
                        Lo sentimos, ocurri&oacute; un error. <br>
                        ERROR <?php echo ($i + 1); ?><br/>
                        CODE:#<?php echo $eex; ?><br/>
                        <button name="regresa" class="btn btn-danger" onclick="window.history.go(-1);
                                return false;"> Regresar </button>
                    </div>
                    <?php
                }
            }
        } else {
            ?>
            <div class="well well-sm" >
                Lo sentimos, ocurri&oacute; un error. <br>
                ERROR <?php echo ($i + 1); ?><br/>
                CODE:#<?php echo $err; ?><br/>
                <button name="regresa" class="btn btn-danger" onclick="window.history.go(-1);
                        return false;"> Regresar </button>
            </div>
            <?php
        }
        break;
}
    