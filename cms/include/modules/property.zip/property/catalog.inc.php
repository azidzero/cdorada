<?php
$activ_autosave = 0;
$lq = mysqli_query($CNN, "SELECT * from cms_translation_lang WHERE status=1");
$language = array();
while ($lr = mysqli_fetch_array($lq)) {
    $language[] = $lr['iso_639_1'];
}
?>
<!-------------------DIV GENERICO------------------->
<div class="modal fade" id="modalgral" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" id="gral_cont">
        </div>
    </div>
</div>
<!----------------------ELIMINAR ITEM------------------->
<div class="modal fade" id="mod_elim" name="mod_elim" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" >
        <div class="modal-content" id="cont_elimadon" >
        </div>
    </div>
</div>
<?php
switch ($o) {
    case 0:
        ?>
        <h2>Catalogo:</h2>
        <h4><b>General</b></h4>
        <button type="button" class="btn btn-primary" alt="Agregar Item al catalogo" title="Agregar Item al catalogo" onclick="muestramodal('1');"><b><i class="fa fa-plus"></i></b></button>
        <!-----------------------TABLA DINAMICA------------------->
        <table id="tbl_admin" class="table table-condensed">
            <thead>
                <tr>
                    <td width="1">ID</td>
                    <td width="15%">Nombre</td>
                    <td>Tipo de Dato</td>
                    <td>Activo</td>
                    <td>Requerido</td>
                    <td>Unidad</td>
                    <td>Val</td>
                    <td width="1">&nbsp;</td>
                </tr>
            </thead>
            <tbody style="align:center;"></tbody>
        </table>
        <!-----------------------INICIA SCRIPT DE LLAMADO A TABLA DINAMICA------------------->
        <script>
            $(document).ready(function () {
                jTable('tbl_admin', 'include/modules/property/catalog.table.php?ntbl=1');
            });
        </script>
        <?php
        break; //TERMINA GENERAL.....
    case 10: //INICIA INTERIOR
        ?>
        <h2>Catalogo:</h2>
        <h4><b>INTERIOR</b></h4>
        <button type="button" class="btn btn-primary" alt="Agregar Item al catalogo" title="Agregar Item al catalogo" onclick="muestramodal('2');"><b><i class="fa fa-plus"></i></b></button>
        <!-----------------------TABLA DINAMICA------------------->
        <table id="tbl_admin" class="table table-condensed">
            <thead>
                <tr>
                    <td width="1">ID</td>
                    <td width="15%">Nombre</td>
                    <td>Tipo de Dato</td>
                    <td>Activo</td>
                    <td>Requerido</td>
                    <td>Unidad</td>
                    <td>Val</td>
                    <td width="1">&nbsp;</td>
                </tr>
            </thead>
            <tbody style="align:center;"></tbody>
        </table>
        <!-----------------------INICIA SCRIPT DE LLAMADO A TABLA DINAMICA------------------->
        <script>
            $(document).ready(function () {
                jTable('tbl_admin', 'include/modules/property/catalog.table.php?ntbl=2');
            });
        </script>
        <?php
        break;
    case 20: //INICIA EXTERIOR
        ?>
        <h2>Catalogo:</h2>
        <h4><b>EXTERIOR</b></h4>
        <button type="button" class="btn btn-primary" alt="Agregar Item al catalogo" title="Agregar Item al catalogo" onclick="muestramodal('3');"><b><i class="fa fa-plus"></i></b></button>
        <!-----------------------TABLA DINAMICA------------------->
        <table id="tbl_admin" class="table table-condensed">
            <thead>
                <tr>
                    <td width="1">ID</td>
                    <td width="15%">Nombre</td>
                    <td>Tipo de Dato</td>
                    <td>Activo</td>
                    <td>Requerido</td>
                    <td>Unidad</td>
                    <td>Val</td>
                    <td width="1">&nbsp;</td>
                </tr>
            </thead>
            <tbody style="align:center;"></tbody>
        </table>
        <!-----------------------INICIA SCRIPT DE LLAMADO A TABLA DINAMICA------------------->
        <script>
            $(document).ready(function () {
                jTable('tbl_admin', 'include/modules/property/catalog.table.php?ntbl=3');
            });
        </script>
        <?php
        break;
    case 30:
        ?>
        <h2>Catalogo:</h2>
        <h4><b>EQUIPAMIENTO</b></h4>
        <button type="button" class="btn btn-primary" alt="Agregar Item al catalogo" title="Agregar Item al catalogo" onclick="muestramodal('4');"><b><i class="fa fa-plus"></i></b></button>
        <!-----------------------TABLA DINAMICA------------------->
        <table id="tbl_admin" class="table table-condensed">
            <thead>
                <tr>
                    <td width="1">ID</td>
                    <td width="15%">Nombre</td>
                    <td>Tipo de Dato</td>
                    <td>Activo</td>
                    <td>Requerido</td>
                    <td>Unidad</td>
                    <td>Val</td>
                    <td width="1">&nbsp;</td>
                </tr>
            </thead>
            <tbody style=""></tbody>
        </table>
        <!-----------------------INICIA SCRIPT DE LLAMADO A TABLA DINAMICA------------------->
        <script>
            $(document).ready(function () {
                jTable('tbl_admin', 'include/modules/property/catalog.table.php?ntbl=4');
            });
        </script>
        <?php
        break;
    case 40:
        ?>
        <h2>ADMINISTRADOR DE CATALOGOS</h2>
        <button class="btn btn-success" alt="Agregar Catalogo" title="Agregar Catalogo" onclick="newcat();" ><i class="fa fa-plus-circle fa-2x"></i></button><br><br>
        <div class="col-lg-8" id="div-cont">
            <table id="tbl_cats" class="table table-striped  table-hover table-bordered table-condensed">
                <thead>
                    <tr class="text-uppercase bg-primary">
                        <th width="1">ID</th>
                        <th>CATALOGO</th>
                        <th>ADDONS</th>
                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody class="bg-success ">
                    <?php
                    $wh = mysqli_query($CNN, "SELECT a.id,a.common,b.caption,b.lang FROM cms_catalog a INNER JOIN cms_catalog_translate b ON (a.`id`=b.`aid`)");
                    while ($w = mysqli_fetch_array($wh)) {
                        ?>
                        <tr id="row_<?php echo $w['id']; ?>">
                            <td><?php echo $w['id']; ?></td>
                            <?php
                            if ($w['common'] != null) {
                                ?><td><?php echo $w['common']; ?></td><?php
                            } else {
                                if ($w['caption'] != null) {
                                    ?><td><?php echo $w['caption']; ?></td><?php
                                } else {
                                    ?><td>NONAME</td><?php
                                }
                            }
                            ?>
                            <td><?php
                                $count = mysqli_query($CNN, "select * from cms_addons where cid={$w['id']}");
                                $noc = mysqli_num_rows($count);
                                echo $noc;
                                ?></td>
                            <td>
                                 <?php if ($w['id'] >4)
                                 {?>
                                <div class=" btn-group ">
                                    <button class="btn btn-danger"alt="Eliminar" title="Eliminar"onclick="delcat(<?php echo $w['id']; ?>)"><i class="fa fa-trash"></i></button>
                                    <button class="btn btn-warning"alt="Editar" title="Editar"onclick="editcat(<?php echo $w['id']; ?>)"><i class="fa fa-edit "></i></button>
                                </div>
                                <?php
                                 }?>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <?php
        break;
}