<?php
$CORE->home();
?>