<?php
switch ($o) {
    case 0:
        ?>
        <form action="./?m=web&s=activity&o=1" method="POST">
            <h4>%activity-new%</h4>
            <table class="table table-condensed">
                <tr>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">%post-title%:</span>
                            <input type="text" id="post-title" name="post-title" class="form-control" />
                        </div>
                    </td>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">%post-short-desc%:</span>
                            <input type="text" id="post-short-desc" name="post-short-desc" class="form-control" />
                        </div>
                    </td>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">%post-cat%:</span>
                            <select id="post-cat" name="post-cat" class="form-control">
                                <option value="0">Ninguna</option>
                                <?php
                                $oq = mysqli_query($CNN, "SELECT * from web_activity_category");
                                while($or=  mysqli_fetch_array($oq)){
                                    echo "<option value=\"{$or["id"]}\">{$or["name"]}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <input type="hidden" id="post-content" name="post-content" />
                        <strong>%post-content%</strong>
                        <div id="post-content-editor"></div>
                    </td>
                </tr>
            </table>            
        </form>
        <script>
            $(document).ready(function(){
               $('#post-content-editor').summernote({height:240});
            });
        </script>
        <?php
        break;
}