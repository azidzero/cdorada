<?php
include("../../../inc/app.conf.php");
$op=filter_input(INPUT_POST,"op");
switch ($op)
{
    case 0:
        $isp=filter_input(INPUT_POST,"isp");
        $name=filter_input(INPUT_POST,"name");
        $pare=0;
        if($isp==1)
        {
            $pare=filter_input(INPUT_POST,"pad");
        }
        $inact=  mysqli_query($CNN, "INSERT INTO web_activity_category (parent,name,lang) values($pare,'$name','es')") or $err="error al guardar la actividad".  mysqli_error($CNN);
        if(!isset($err))
        {
            $nid=  mysqli_insert_id($CNN);
          echo "1|$nid";
        }
        else
        {
            echo "0|0|".$err;
        }
        break;
        case 80:
        $id = filter_input(INPUT_POST, "elim_id");
        $prop = filter_input(INPUT_POST, "prop_id");
        $q = mysqli_query($CNN, "SELECT * from web_activity_gallery WHERE id=$id and aid=$prop") or die(mysqli_error($CNN));
        while ($r = mysqli_fetch_array($q)) {
            unlink("../../../content/upload/activity/" . $r['name'] . "_m.jpg");
            unlink("../../../content/upload/activity/" . $r['name'] . "_b.jpg");
        }
        $del = mysqli_query($CNN, "DELETE from web_activity_gallery where aid=$prop and id=$id ")OR DIE(mysqli_error($CNN));
        if (!$del) {
            ?>
            <label >ERROR AL ELIMINAR LOS DATOS</label>
            <?php
        } else {
            ?>
            <label >Eliminado correctamente</label>
            <?php
        }
        break;
}

