<?php
include("../../../inc/app.conf.php");
$lng = filter_input(INPUT_POST, "language");
?>
<div class="row">
    <div class="col-lg-3">
        <div class="form-group">
            <label for="exampleInputEmail1">Nombre:</label>
            <input type="text" class="form-control" id="namcat" placeholder="Nombre de la categoria">
        </div>
    </div>
    <div class="col-lg-3">
        <div class="form-group">
            <label for="exampleInputEmail1">¿Es padre? </label><br>
            <input type="checkbox" class="form-control" id="ipar" value="1" onclick="isparent();" checked>
        </div>
    </div>
    <div class="col-lg-4"  id="parent" style="display: none;">
        <div class="form-group">
            <label for="exampleInputEmail1">Selecciona:</label>
            <select id="myparent" class="form-control ">
                <option value="null"></option>
                <?php
                $gpp = mysqli_query($CNN, "select * from web_activity_category where parent=0");
                while ($p = mysqli_fetch_array($gpp)) {
                    ?><option value="<?php echo $p['id']; ?>"><?php echo $p['name']; ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
    </div>
    <div class="col-lg-2 text-center"style="vertical-align:bottom; "><br>
        <button class="btn btn-success" onclick="savecat()"><span class="fa fa-save"></span></button>
    </div>
    <div
</div>
<?php
$gc = "select * from web_activity_category where parent=0 and lang='$lng'";
$gcat = mysqli_query($CNN, $gc)or $erra = "error" . mysqli_error($CNN);
if (!isset($erra)) {
    ?>
    <table class="table table-condensed table-bordered table-hover">
        <thead>
            <tr>
                <th>Categoria</th>
                <th>Parent</th>
                <th>Lenguaje</th>
                <th>Acci&oacute;n</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($c = mysqli_fetch_array($gcat)) {
                ?>
                <tr class="<?php
                if ($c["parent"] == 0) {
                    echo "text-success";
                }
                ?>">
                    <td class="text-capitalize"><?php echo $c["name"]; ?></td>
                    <td><?php if ($c["parent"] == 0) { ?><span class="fa fa-lock fa-2x"></span><?php } else { ?><span class="fa fa-unlock-alt"></span><?php } ?></td>
                    <td><?php echo $c["lang"]; ?></td>
                    <td></td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>
    <?php
} else {
    echo $erra;
}