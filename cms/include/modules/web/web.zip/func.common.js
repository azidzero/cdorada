Dropzone.autoDiscover = false;
function unifiyContent() {
    $('#post-content-es').val($('#post-content-editor-es').code());
    $('#post-content-en').val($('#post-content-editor-en').code());
    $('#post-content-fr').val($('#post-content-editor-fr').code());
    $('#post-content-ru').val($('#post-content-editor-ru').code());
}
$(document).ready(function () {
    $('#post-content-editor-es').summernote({height: 240});
    $('#post-content-editor-en').summernote({height: 240});
    $('#post-content-editor-fr').summernote({height: 240});
    $('#post-content-editor-ru').summernote({height: 240});
});
function showCat(lang) {
    $.ajax({
        method: 'POST',
        url: 'include/modules/web/cat.admin.php',
        data: {language: lang}
    }).done(function (response) {
        $("#catmodal").modal('show');
        $("#gridSystemModalLabel").html('Administrador de Categorias');
        $("#body-cat").html(response);
        console.log(response);
    });
}
function isparent()
{
    var ch = document.getElementById("ipar").checked;
    if (ch === true)
    {
        document.getElementById("parent").style.display = "none";
    }
    else
    {
        document.getElementById("parent").style.display = "inline";
    }
}

function savecat()
{
    var n = document.getElementById("namcat").value;//nombre de categoria
    var c = document.getElementById("ipar").checked;//es padre
    var child = null;//
    var chk = 0;
    if (c === false)
    {
        chk = 1;
        child = document.getElementById("myparent").value;
    }
    $.ajax({
        data: {"op": 0, "name": n, "isp": chk, "pad": child},
        url: "include/modules/web/action.activity.php",
        type: 'post',
        success: function (data)
        {
            var arr = data.split("|");
            switch (arr[0])
            {
                case '1':
                    $("#catmodal").modal('hide');
                    $('#post-cat-es').append('<option value="' + arr[1] + '"selected="selected">' + n + '</option>');

                    $.bootstrapGrowl("AGREGADO CORRECTAMENTE", {type: 'Success'});
                    break;
                case '0':
                    $.bootstrapGrowl(arr[1], {type: 'warning'});
                    break;
            }
        }
    });
}
function traeventana(uid, oc, elaid) {
    //alert(uid+'--'+ oc+'--'+elaid);
    $.ajax({
        method: "POST",
        url: "include/modules/web/catalogo.json.php",
        data: {"id": uid, "op": oc},
        dataType: 'json' // esto es para decirle que esperamos el resultado en formato json
    }).done(function (json) {
        document.getElementById("tit").innerHTML += json.name;
        $("#elim_id").val(json.id);
        $("#mod_elim").modal('show');
    });

}
function eliminaitemimage(elaid)
{
    $.ajax({
        data: $("#form_elim").serialize(),
        url: "include/modules/web/action.activity.php",
        type: 'post',
        success: function (data)
        {
            $("#mod_elim").modal('hide');
            $.ajax({
                method: "POST",
                url: "include/modules/web/gallery.ajax.php",
                data: {"id": elaid}
            }).done(function (data) {
                $("#gal_activiy").html(data);
            });
            //:::::::::::::::::::::::::
        }
    });
}