<?php
$locale = $CORE->modules[$m]->locale;
switch ($o) {
    case 0:
        $lq = mysqli_query($CNN, "SELECT * from cms_translation_lang WHERE status=1");
        $language = array();
        while ($lr = mysqli_fetch_array($lq)) {
            $language[] = $lr['iso_639_1'];
        }
        ?>
        <form action="./?m=web&s=activity&o=1" method="POST" enctype="multipart/form-data">
            <div>
                <ul class="nav nav-tabs" role="tablist">
                    <?php
                    foreach ($language as $L) {
                        ?>
                        <li role="presentation" class="<?php
                        if ($L == "es") {
                            echo "active";
                        }
                        ?>">
                            <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab">
                                <?php echo $L; ?>
                                <?php if ($L == "es") { ?>
                                    <span class="label label-danger"><?php echo $lang->getString("activity", "post-label-required"); ?></span>
                                    <?php
                                }
                                ?>
                            </a>
                        </li>
                        <?php
                    }
                    ?>
                </ul>
                <div class="tab-content">
                    <?php
                    foreach ($language as $L) {
                        ?>
                        <div role="tabpanel" class="tab-pane <?php
                        if ($L == "es") {
                            echo "active";
                        }
                        ?>" id="tab_<?php echo $L; ?>">
                            <table class="table table-condensed">
                                <tr>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo $lang->getString("activity", "post-title"); ?>:</span>
                                            <input type="text" id="post-title-<?php echo $L; ?>" name="post-title-<?php echo $L; ?>" class="form-control" />
                                        </div>
                                    </td>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo $lang->getString("activity", "post-short-desc"); ?>:</span>
                                            <input type="text" id="post-short-desc-<?php echo $L; ?>" name="post-short-desc-<?php echo $L; ?>" class="form-control" />
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo $lang->getString("activity", "post-cat"); ?>:</span>
                                            <select id="post-cat-<?php echo $L; ?>" name="post-cat-<?php echo $L; ?>" class="form-control">
                                                <option value="0"><?php echo $lang->getString("activity", "post-cat-default"); ?></option>
                                                <?php
                                                $oq = mysqli_query($CNN, "SELECT * from web_activity_category");
                                                while ($or = mysqli_fetch_array($oq)) {
                                                    echo "<option value=\"{$or["id"]}\">{$or["name"]}</option>";
                                                }
                                                ?>
                                            </select>
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" onclick="showCat('<?php echo $L; ?>')" type="button"><i class="fa fa-plus"></i></button>
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo $lang->getString("activity", "post-cover"); ?>:</span>
                                            <input type="file" id="cover-<?php echo $L; ?>" name="cover-<?php echo $L; ?>" class="form-control" />
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <input type="hidden" id="post-content-<?php echo $L; ?>" name="post-content-<?php echo $L; ?>" />
                                        <strong><?php echo $lang->getString("activity", "post-content"); ?></strong>
                                        <div id="post-content-editor-<?php echo $L; ?>"></div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <?php
                    }
                    ?>                    
                </div>
            </div>
            <div class="well well-sm">
                <button class="btn btn-primary" onclick="unifiyContent()"><?php echo $lang->getString("activity", "post-btn-save"); ?></button>
            </div>
        </form>
        <div class="modal fade bs-example-modal-lg"id="catmodal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="gridSystemModalLabel">Modal title</h4>
                    </div>
                    <div class="modal-body" id="body-cat">
                    </div>
                </div>
            </div>
        </div>
        <?php
        break;
    case 1:
        $lq = mysqli_query($CNN, "SELECT * from cms_translation_lang WHERE status=1") or die(mysqli_error($CNN));
        $language = array();
        while ($lr = mysqli_fetch_array($lq)) {
            $language[] = $lr['iso_639_1'];
        }
        $fields = array('post-title', 'post-short-desc', 'post-cat', 'post-content');
        $data = array();
        foreach ($language as $L) {
            unset($e);
            foreach ($fields as $F) {
                $data[$L][$F] = mysqli_real_escape_string($CNN, filter_input(INPUT_POST, $F . "-" . $L));
            }
            // # SAVE
            $date = date("Y-m-d");
            $time = date("H:i:s");
        }
        mysqli_query($CNN, "INSERT INTO web_activity(fecha,hora) VALUES('$date','$time')") or $e = mysqli_error($CNN);
        if (!isset($e)) {
            echo "<h4>Se ha guardado la actividad.</h4>";
            $id = mysqli_insert_id($CNN);
            $str = md5($id);
            mysqli_query($CNN, "UPDATE web_activity SET str='$str' WHERE id='$id'") or die(mysqli_error($CNN));
            // # DATA
            foreach ($language as $L) {
                unset($le);
                mysqli_query($CNN, "INSERT INTO web_activity_translate(uid,lang,title,short_desc,content,category) 
                    VALUES('$id','$L','{$data[$L]['post-title']}','{$data[$L]['post-short-desc']}','{$data[$L]['post-content']}','{$data[$L]['post-cat']}')") or $le = mysqli_error($CNN);
                if (!isset($le)) {
                    // # COVER's
                    $path = 'content/activity/item_' . str_pad($id, 6, '0', STR_PAD_LEFT) . "-" . $L . '.jpg';
                    if ($_FILES['cover-' . $L]['error'] == 0) {
                        if (move_uploaded_file($_FILES['cover-' . $L]['tmp_name'], $path)) {
                            echo "<b>Imagen de portada importada para $L</b><br/>";
                        } else {
                            echo "<b class=\"text-danger\">No se pudo actualizar la portada para $L</b><br/>";
                        }
                    }
                } else {
                    echo "<h4>ERROR:</h4>";
                    echo $le;
                }
            }
        } else {
            echo "<h4>ERROR:</h4>";
            echo $e;
        }
        if (!isset($le)) {
            ?>
            <div class="row">
                <div class="col-lg-4">
                    <h2>¿Desea subir imagenes?</h2>
                    <a href="javascript:void(0);" onclick="uploadimage(<?php echo $id; ?>)" class="btn btn-success"><span class="fa fa-image"></span><b>+</b></a>
                </div>
            </div>
            <div class="row" id="activity_upload">
                <div class="col-lg-12">
                    <div id="act_ima" class="dropzone"></div>
                    <script>
                        var dz = $("#act_ima").dropzone({
                            maxFilesize: 200,
                            url: "content/upload/activity/upload.inc.php?id=<?php echo $id; ?>",
                            complete: function (file) {
                                $.ajax({
                                    method: "POST",
                                    url: "include/modules/web/gallery.ajax.php",
                                    data: {"id": "<?php echo $id; ?>"}
                                }).done(function (data) {
                                    $("#gal_activiy").html(data);
                                });
                            }
                        });
                        $(document).ready(function ()
                        {
                            $.ajax({
                                method: "POST",
                                url: "include/modules/web/gallery.ajax.php",
                                data: {"id": "<?php echo $id; ?>"}
                            }).done(function (data) {
                                $("#gal_activiy").html(data);
                            });
                        });
                    </script>
                </div>
                <div class="col-lg-12" id="gal_activiy">
                </div>
            </div>
            <div class="modal fade" id="mod_elim" name="mod_elim" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" >
                    <div class="modal-content" >
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="exampleModalLabel">Eliminar</h4>
                        </div>
                        <div class="modal-body" id="elimina_c" name="elimina_c">
                            <form id='form_elim' name='form_elim' method='POST' action="" >
                                <input type="text" name="op" id="op" value="80" class="hidden">
                                <input type="text" name="elim_id" id="elim_id" class="hidden">
                                <input type="text" value="<?php echo $id; ?>"name="prop_id" id="prop_id" class="hidden">
                                <div class="form-group">
                                    <label for="recipient-name" class="control-label">¿Esta seguro que desea eliminar la imagen?:</label>
                                    <div id="tit" name="tit"><div>
                                        </div>
                                        <input type="text" name="el_id" id="el_id" class="hidden">
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                        <button type="button" class="btn btn-success" id="aceptar" name="aceptar" onclick="eliminaitemimage(<?php echo $id; ?>);">Aceptar</button>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }

        break;
    case 2:
        ?>
        <table id="tbl" class="table table-condensed">
            <thead>
                <tr>
                    <td>ID</td>
                    <td>Titulo</td>
                    <td>Descripcion Corta</td>
                    <td>Categoria</td>
                    <td>&nbsp;</td>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
        <script>
            $(document).ready(function () {
                jTable('tbl', 'include/modules/web/activity.table.php');
            });
        </script>
        <?php
        break;
    case 3:
        $id = filter_input(INPUT_GET, "id");
        $lq = mysqli_query($CNN, "SELECT * from cms_translation_lang WHERE status=1");
        $language = array();
        while ($lr = mysqli_fetch_array($lq)) {
            $language[] = $lr['iso_639_1'];
        }
        ?>
        <form action="./?m=web&s=activity&o=4" method="POST" enctype="multipart/form-data">
            <input type="hidden" id="id" name="id" value="<?php echo $id; ?>" />
            <div>
                <ul class="nav nav-tabs" role="tablist">
                    <?php
                    foreach ($language as $L) {
                        ?>
                        <li role="presentation" class="<?php
                        if ($L == "es") {
                            echo "active";
                        }
                        ?>">
                            <a href="#tab_<?php echo $L; ?>" aria-controls="tab_<?php echo $L; ?>" role="tab" data-toggle="tab">
                                <?php echo $L; ?>
                                <?php if ($L == "es") { ?>
                                    <span class="label label-danger"><?php echo $lang->getString("activity", "post-label-required"); ?></span>
                                    <?php
                                }
                                ?>
                            </a>
                        </li>
                        <?php
                    }
                    ?>
                </ul>
                <div class="tab-content">
                    <?php
                    foreach ($language as $L) {
                        $q = mysqli_query($CNN, "SELECT * from web_activity_translate WHERE uid='$id' AND lang='$L'");
                        $n = mysqli_num_rows($q);
                        if ($n > 0) {
                            while ($r = mysqli_fetch_array($q)) {
                                $ptitle = $r["title"];
                                $pcontent = $r["content"];
                                $pshort = $r["short_desc"];
                            }
                        }
                        ?>
                        <div role="tabpanel" class="tab-pane <?php
                        if ($L == "es") {
                            echo "active";
                        }
                        ?>" id="tab_<?php echo $L; ?>">
                            <table class="table table-condensed">
                                <tr>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo $lang->getString("activity", "post-title"); ?>:</span>
                                            <input type="text" id="post-title-<?php echo $L; ?>" name="post-title-<?php echo $L; ?>" class="form-control" value="<?php echo $ptitle; ?>" />
                                        </div>
                                    </td>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo $lang->getString("activity", "post-short-desc"); ?>:</span>
                                            <input type="text" id="post-short-desc-<?php echo $L; ?>" name="post-short-desc-<?php echo $L; ?>" class="form-control" value="<?php echo $pshort; ?>" />
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo $lang->getString("activity", "post-cat"); ?>:</span>
                                            <select id="post-cat-<?php echo $L; ?>" name="post-cat-<?php echo $L; ?>" class="form-control">
                                                <option value="0"><?php echo $lang->getString("activity", "post-cat-default"); ?></option>
                                                <?php
                                                $oq = mysqli_query($CNN, "SELECT * from web_activity_category");
                                                while ($or = mysqli_fetch_array($oq)) {
                                                    echo "<option value=\"{$or["id"]}\">{$or["name"]}</option>";
                                                }
                                                ?>
                                            </select>
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" onclick="showCat('<?php echo $L; ?>')" type="button"><i class="fa fa-plus"></i></button>
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo $lang->getString("activity", "post-cover"); ?>:</span>
                                            <input type="file" id="cover-<?php echo $L; ?>" name="cover-<?php echo $L; ?>" class="form-control" />
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <input type="hidden" id="post-content-<?php echo $L; ?>" name="post-content-<?php echo $L; ?>" />
                                        <strong><?php echo $lang->getString("activity", "post-content"); ?></strong>
                                        <div id="post-content-editor-<?php echo $L; ?>"><?php echo stripslashes($pcontent); ?></div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <?php
                    }
                    ?>                    
                </div>
            </div>
            <div class="well well-sm">
                <button class="btn btn-primary" onclick="unifiyContent()"><?php echo $lang->getString("activity", "post-btn-save"); ?></button>
            </div>
        </form>
        <div class="row" id="activity_upload">
                <div class="col-lg-12">
                    <div id="act_ima" class="dropzone"></div>
                    <script>
                        var dz = $("#act_ima").dropzone({
                            maxFilesize: 200,
                            url: "content/upload/activity/upload.inc.php?id=<?php echo $id; ?>",
                            complete: function (file) {
                                $.ajax({
                                    method: "POST",
                                    url: "include/modules/web/gallery.ajax.php",
                                    data: {"id": "<?php echo $id; ?>"}
                                }).done(function (data) {
                                    $("#gal_activiy").html(data);
                                });
                            }
                        });
                        $(document).ready(function ()
                        {
                            $.ajax({
                                method: "POST",
                                url: "include/modules/web/gallery.ajax.php?id=<?php echo $id;?>",
                                data: {"id": "<?php echo $id; ?>"}
                            }).done(function (data) {
                                $("#gal_activiy").html(data);
                            });
                        });
                    </script>
                </div>
                <div class="col-lg-12" id="gal_activiy">
                </div>
            </div>
            <div class="modal fade" id="mod_elim" name="mod_elim" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" >
                    <div class="modal-content" >
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="exampleModalLabel">Eliminar</h4>
                        </div>
                        <div class="modal-body" id="elimina_c" name="elimina_c">
                            <form id='form_elim' name='form_elim' method='POST' action="" >
                                <input type="text" name="op" id="op" value="80" class="hidden">
                                <input type="text" name="elim_id" id="elim_id" class="hidden">
                                <input type="text" value="<?php echo $id; ?>"name="prop_id" id="prop_id" class="hidden">
                                <div class="form-group">
                                    <label for="recipient-name" class="control-label">¿Esta seguro que desea eliminar la imagen?:</label>
                                    <div id="tit" name="tit"><div>
                                        </div>
                                        <input type="text" name="el_id" id="el_id" class="hidden">
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                        <button type="button" class="btn btn-success" id="aceptar" name="aceptar" onclick="eliminaitemimage(<?php echo $id; ?>);">Aceptar</button>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        break;
    case 4:
        $id = filter_input(INPUT_POST, 'id');
        $lq = mysqli_query($CNN, "SELECT * from cms_translation_lang WHERE status=1") or die(mysqli_error($CNN));
        $language = array();
        while ($lr = mysqli_fetch_array($lq)) {
            $language[] = $lr['iso_639_1'];
        }
        $fields = array('post-title', 'post-short-desc', 'post-cat', 'post-content');
        $data = array();
        foreach ($language as $L) {
            unset($e);
            foreach ($fields as $F) {
                $data[$L][$F] = mysqli_real_escape_string($CNN, filter_input(INPUT_POST, $F . "-" . $L));
            }
            // # SAVE
            $date = date("Y-m-d");
            $time = date("H:i:s");
        }
        // # DATA
        foreach ($language as $L) {
            unset($le);
            $content = $data[$L]['post-content'];
            $SQL = "UPDATE web_activity_translate SET 
                title='{$data[$L]['post-title']}'
                ,short_desc='{$data[$L]['post-short-desc']}'
                ,content='$content' WHERE uid='$id' AND lang='$L'";
            mysqli_query($CNN, $SQL) or $le = mysqli_error($CNN) or $le = mysqli_errno($CNN) . ": " . mysqli_error($CNN);
            if (!isset($le)) {
                echo "<h4>Se ha actualizado la traduccion de la Actividad para <strong>[$L]</strong>.</h4>";
                // # COVER's
                $path = 'content/activity/item_' . str_pad($id, 6, '0', STR_PAD_LEFT) . "-" . $L . '.jpg';
                if ($_FILES['cover-' . $L]['error'] == 0) {
                    if (move_uploaded_file($_FILES['cover-' . $L]['tmp_name'], $path)) {
                        echo "Imagen de portada importada para <strong>[$L]</strong><br/>";
                    } else {
                        echo "<b class=\"text-danger\">No se pudo actualizar la portada para $L</b><br/>";
                    }
                }
            } else {
                echo "<h4>ERROR:</h4>";
                echo $le . "<br/>" . $SQL;
            }
        }
        break;
    case 5:
        $id = filter_input(INPUT_GET, "id");
        ?>
        <form action="./?m=web&s=activity&o=6" method="POST">
            <input type="hidden" id="id" name="id" value="<?php echo $id; ?>" />
            <div class="alert alert-warning">
                <h4>Esta seguro de eliminar la actividad</h4>
                <p>Esta accion no se puede deshacer, <strong>esta seguro que deseas continuar?</strong></p>
                <br/>
                <div class="btn-group">
                    <a href="./?m=web&s=activity&o=0" class="btn btn-warning"><i class="fa fa-plus"></i> Agregar Nuevo</a>
                    <a href="./?m=web&s=activity&o=2" class="btn btn-warning"><i class="fa fa-chevron-left"></i> Regresar</a>
                    <button type="submit" class="btn btn-warning">Continuar <i class="fa fa-chevron-right"></i></button>
                </div>
            </div>
        </form>
        <?php
        break;
    case 6:
        $id = filter_input(INPUT_POST, "id");
        mysqli_query($CNN, "DELETE FROM web_activity WHERE id='$id'") or $e = mysqli_error($CNN);
        mysqli_query($CNN, "DELETE FROM web_activity_translate WHERE uid='$id'") or $e = mysqli_error($CNN);
        $lq = mysqli_query($CNN, "SELECT * from cms_translation_lang WHERE status=1");
        $language = array();
        while ($lr = mysqli_fetch_array($lq)) {
            $L = $lr['iso_639_1'];
            $path = 'content/activity/item_' . str_pad($id, 6, '0', STR_PAD_LEFT) . "-" . $L . '.jpg';
            unlink($path);
        }
        if (!isset($e)) {
            ?>
            <div class="alert alert-info">
                <h3>Se ha eliminado la actividad exitosamente!</h3>
            </div>
            <?php
        } else {
            ?>
            <div class="alert alert-danger">
                <h3>Ha ocurrido un error al eliminar la actividad!</h3>
                <p><?php echo $e; ?></p>
            </div>
            <?php
        }
        break;
}